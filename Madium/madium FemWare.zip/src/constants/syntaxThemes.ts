// Shared syntax theme definitions

export interface SyntaxTheme {
  label: string;
  kw:   string;
  str:  string;
  cmt:  string;
  num:  string;
  fn:   string;
  svc:  string;   // Roblox services (ReplicatedStorage, etc.)
  rblx: string;   // Roblox globals (game, workspace, script) + identifiers
  type: string;   // Types (string, number, etc.)
  op:   string;   // Operators: = , ~ .
  bi:   string;   // Built-in functions: cloneref, getgenv, setmetatable, etc.
}

// Mode stored in theme.syntaxMode:
//   'preset' — one of the named SYNTAX_THEMES below
//   'custom' — per-token colors, each can be auto-derived or manually picked
export type SyntaxMode = 'preset' | 'custom';

export interface CustomSyntaxColors {
  kw:   string;
  str:  string;
  cmt:  string;
  num:  string;
  fn:   string;
  svc:  string;
  rblx: string;
  type: string;
  op:   string;
  bi:   string;
}

// Tracks which tokens auto-derive from theme hue in custom mode
export interface SyntaxAutoFlags {
  kw:   boolean;
  str:  boolean;
  cmt:  boolean;
  num:  boolean;
  fn:   boolean;
  svc:  boolean;
  rblx: boolean;
  type: boolean;
  op:   boolean;
  bi:   boolean;
}

// The core aesthetic presets
// 'Theme Color' is a special sentinel — resolved dynamically from hue
export const SYNTAX_THEMES: SyntaxTheme[] = [
  {
    label: 'Theme Color',
    // These are placeholders; resolveSyntaxColors handles this preset dynamically
    kw: '__auto__', str: '__auto__', cmt: '__auto__', num: '__auto__',
    fn: '__auto__', svc: '__auto__', rblx: '__auto__', type: '__auto__',
    op: '__auto__', bi: '__auto__',
  },

  {
    label: 'Soft Blue',
    kw: '#7eb8f7', str: '#f4a97f', cmt: '#81c784', num: '#c49ef5',
    fn: '#7ee8f7', svc: '#4EC9B0', rblx: '#9CDCFE', type: '#4EC9B0',
    op: '#c0c8d8', bi: '#d7a4f0',
  },

  // High-saturation pure rainbow
  {
    label: 'Gay (Rainbow)',
    kw: '#FF4565', str: '#FF9500', cmt: '#7A8490', num: '#FFEA00',
    fn: '#00FF66', svc: '#00D4FF', rblx: '#B85CFF', type: '#FF33CC',
    op: '#ffffff', bi: '#FF6EFF',
  },

  // Strictly Cyan, Vibrant Pink, and Darker Silver/White
  {
    label: 'Trans Flag',
    kw: '#5BCEFA', str: '#C2C6D2', cmt: '#64748B', num: '#FF7EB3',
    fn: '#FF7EB3', svc: '#5BCEFA', rblx: '#D8DBE2', type: '#5BCEFA',
    op: '#8ab4c8', bi: '#b0e0f5',
  },

  {
    label: 'Midnight',
    kw: '#CBA6F7', str: '#A6E3A1', cmt: '#6C7086', num: '#FAB387',
    fn: '#89B4FA', svc: '#F38BA8', rblx: '#CDD6F4', type: '#F9E2AF',
    op: '#9399b2', bi: '#e8b0f9',
  },

  {
    label: 'Vaporwave',
    kw: '#FF71CE', str: '#05FFA1', cmt: '#6B5B95', num: '#B967FF',
    fn: '#01CDFE', svc: '#FFB48F', rblx: '#FFFFFF', type: '#01CDFE',
    op: '#cc88ff', bi: '#FF71CE',
  },
];

export const DEFAULT_SYNTAX_THEME = 'Soft Blue';
export const DEFAULT_SYNTAX_MODE: SyntaxMode = 'preset';

// Resolves syntax colors based on mode and auto-flags
export function resolveSyntaxColors(
  mode: SyntaxMode,
  presetLabel: string,
  customColors: CustomSyntaxColors | null,
  autoFlags: SyntaxAutoFlags | null,
  themeH: number,
  themeS: number,
  themeL: number,
): CustomSyntaxColors {
  const flags = autoFlags ?? {
    kw: false, str: false, cmt: false, num: false, fn: false,
    svc: false, rblx: false, type: false, op: false, bi: false,
  };
  const anyAuto = Object.values(flags).some(Boolean);

  const hsl = (hue: number, s: number, l: number) =>
    `hsl(${((hue % 360) + 360) % 360},${s}%,${l}%)`;

  const useS  = themeS;
  const baseL = themeL;

  // Auto colors — all derived from the theme hue
  const autoColors: CustomSyntaxColors = {
    kw:   hsl(themeH,        useS,          Math.max(25, baseL - 5)),
    fn:   hsl(themeH,        useS * 0.9,    Math.min(85, baseL + 10)),
    str:  hsl(themeH,        useS * 0.8,    baseL),
    num:  hsl(themeH,        useS * 0.7,    Math.min(80, baseL + 5)),
    cmt:  hsl(themeH,        Math.min(useS, 25), Math.max(20, baseL - 15)),
    svc:  hsl(themeH + 15,  useS * 0.85,   baseL - 3),
    rblx: hsl(themeH + 10,  useS * 0.9,    Math.min(75, baseL + 5)),
    type: hsl(themeH + 5,   useS * 0.75,   baseL - 2),
    op:   hsl(themeH - 10,  useS * 0.4,    Math.min(75, baseL + 12)),
    bi:   hsl(themeH + 25,  useS * 0.95,   Math.min(80, baseL + 8)),
  };

  if (mode === 'preset') {
    // Special case: "Theme Color" preset — always fully auto-derived
    if (presetLabel === 'Theme Color') return autoColors;

    let found = SYNTAX_THEMES.find(t => t.label === presetLabel);

    // Check local storage for user-saved presets if not found in built-ins
    if (!found) {
      try {
        const r = localStorage.getItem('fem-saved-syntax-themes');
        if (r) {
          const saved = JSON.parse(r) as SyntaxTheme[];
          found = saved.find(t => t.label === presetLabel);
        }
      } catch {}
    }

    found = found ?? SYNTAX_THEMES.find(t => t.label === 'Soft Blue') ?? SYNTAX_THEMES[1];

    return {
      kw:   found.kw,   str:  found.str,  cmt:  found.cmt,
      num:  found.num,  fn:   found.fn,   svc:  found.svc,
      rblx: found.rblx, type: found.type,
      op:   found.op   ?? autoColors.op,
      bi:   found.bi   ?? autoColors.bi,
    };
  }

  if (!customColors) {
    return anyAuto ? autoColors : {
      kw: '#ff0000', str: '#ff0000', cmt: '#ff0000', num: '#ff0000',
      fn: '#ff0000', svc: '#ff0000', rblx: '#ff0000', type: '#ff0000',
      op: '#ff0000', bi: '#ff0000',
    };
  }

  return {
    kw:   flags.kw   ? autoColors.kw   : customColors.kw,
    str:  flags.str  ? autoColors.str  : customColors.str,
    cmt:  flags.cmt  ? autoColors.cmt  : customColors.cmt,
    num:  flags.num  ? autoColors.num  : customColors.num,
    fn:   flags.fn   ? autoColors.fn   : customColors.fn,
    svc:  flags.svc  ? autoColors.svc  : customColors.svc,
    rblx: flags.rblx ? autoColors.rblx : customColors.rblx,
    type: flags.type ? autoColors.type : customColors.type,
    op:   flags.op   ? autoColors.op   : customColors.op,
    bi:   flags.bi   ? autoColors.bi   : customColors.bi,
  };
}