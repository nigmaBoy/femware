import { useState, useRef, useCallback, useEffect } from 'react';
import { open } from '@tauri-apps/plugin-dialog';
import { readFile } from '@tauri-apps/plugin-fs';
import { useFemTheme, hexToHsl, hslToHex } from '../../context/themeContext';
import { SYNTAX_THEMES, DEFAULT_SYNTAX_THEME, DEFAULT_SYNTAX_MODE, resolveSyntaxColors, type SyntaxTheme, type SyntaxMode, type CustomSyntaxColors, type SyntaxAutoFlags } from '../../constants/syntaxThemes';

import topImgDefault    from '../../assets/top img.png';
import bottomImgDefault from '../../assets/bottom img.png';
import astolfoAsset     from '../../assets/astolfo.png';
import boyKisserBg      from '../../assets/boy kisser.png';
import boyKisserTop     from '../../assets/boy kisser top.png';
import boyKisserBottom  from '../../assets/boy kisser bottom.png';

// ── Color Space Converters (To allow UI to use HSB/HSV while engine uses HSL) ──
function hslToHsv(h: number, s: number, l: number) {
  const l_ = l / 100, s_ = s / 100;
  const v = l_ + s_ * Math.min(l_, 1 - l_);
  const sHsv = v === 0 ? 0 : 2 * (1 - l_ / v);
  return { h, s: sHsv * 100, v: v * 100 };
}

function hsvToHsl(h: number, s: number, v: number) {
  const s_ = s / 100, v_ = v / 100;
  const l = v_ * (1 - s_ / 2);
  const sHsl = l === 0 || l === 1 ? 0 : (v_ - l) / Math.min(l, 1 - l);
  return { h, s: sHsl * 100, l: l * 100 };
}

async function pickImageAsDataUrl(): Promise<string | null> {
  try {
    const selected = await open({ multiple: false, filters: [{ name: 'Images', extensions: ['png','jpg','jpeg','gif','webp','avif','bmp'] }] });
    if (!selected || typeof selected !== 'string') return null;
    const bytes = await readFile(selected);
    const ext = selected.split('.').pop()?.toLowerCase() ?? 'png';
    const mime = (ext==='jpg'||ext==='jpeg') ? 'image/jpeg' : ext==='gif' ? 'image/gif' : ext==='webp' ? 'image/webp' : ext==='bmp' ? 'image/bmp' : ext==='avif' ? 'image/avif' : 'image/png';
    let b64 = '';
    const chunk = 8192;
    for (let i = 0; i < bytes.length; i += chunk) {
      b64 += String.fromCharCode(...bytes.subarray(i, i + chunk));
    }
    return `data:${mime};base64,${btoa(b64)}`;
  } catch { return null; }
}

const SAVED_THEMES_KEY = 'fem-saved-themes';
interface SavedTheme { name: string; theme: Record<string, unknown>; savedAt: number; }

function loadSavedThemesSync(): SavedTheme[] {
  try { const raw = localStorage.getItem(SAVED_THEMES_KEY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}
function persistSavedThemes(themes: SavedTheme[]): void {
  try { localStorage.setItem(SAVED_THEMES_KEY, JSON.stringify(themes)); } catch {}
}

const SAVED_SYNTAX_KEY = 'fem-saved-syntax-themes';
function loadSavedSyntaxSync(): SyntaxTheme[] {
  try { const raw = localStorage.getItem(SAVED_SYNTAX_KEY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}
function persistSavedSyntax(themes: SyntaxTheme[]): void {
  try { localStorage.setItem(SAVED_SYNTAX_KEY, JSON.stringify(themes)); } catch {}
}

function Label({ children }: { children: React.ReactNode }) {
  return <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>{children}</div>;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div style={{ borderRadius: 14, padding: '16px 18px', background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a22)', boxShadow: 'var(--fem-inset-md)', display: 'flex', flexDirection: 'column', gap: 14 }}>
      <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--fem-darker)' }}>{title}</div>
      {children}
    </div>
  );
}

function CollapsibleSection({ title, children, defaultOpen = false }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const key = 'fem-collapse-' + title.replace(/\s+/g, '-').toLowerCase();
  const [open, setOpen] = useState(() => {
    try { const stored = localStorage.getItem(key); return stored !== null ? stored === 'true' : defaultOpen; } catch { return defaultOpen; }
  });
  const toggle = () => setOpen(v => { const next = !v; try { localStorage.setItem(key, String(next)); } catch {} return next; });
  return (
    <div style={{ borderRadius: 14, background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a22)', boxShadow: 'var(--fem-inset-md)', display: 'flex', flexDirection: 'column' }}>
      <div onClick={toggle} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 18px', cursor: 'pointer', userSelect: 'none' }}>
        <span style={{ fontSize: 13, fontWeight: 700, color: 'var(--fem-darker)' }}>{title}</span>
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0, transition: 'transform 0.2s', transform: open ? 'rotate(0deg)' : 'rotate(-90deg)' }}>
          <path d="M2 4L6 8L10 4" stroke="var(--fem-muted)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </div>
      {open && <div style={{ padding: '0 18px 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>{children}</div>}
    </div>
  );
}

function FemSlider({ label, value, min = 0, max = 100, unit = '', onChange, gradient }: { label: string; value: number; min?: number; max?: number; unit?: string; onChange: (v: number) => void; gradient?: string; }) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between' }}>
        <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)' }}>{label}</span>
        <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--fem-base)', minWidth: 36, textAlign: 'right' }}>{value}{unit}</span>
      </div>
      <div style={{ position: 'relative', height: 20, display: 'flex', alignItems: 'center' }}>
        <div style={{ position: 'absolute', left: 0, right: 0, height: 6, borderRadius: 3, background: gradient || 'linear-gradient(to right, var(--fem-a25), var(--fem-base))', boxShadow: 'inset 0 1px 3px rgba(0,0,0,0.1)' }} />
        <input type="range" min={min} max={max} value={value} onChange={e => onChange(Number(e.target.value))} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer', margin: 0 }} />
        <div style={{ position: 'absolute', left: `calc(${Math.max(0, pct)}% - 9px)`, width: 18, height: 18, borderRadius: '50%', background: 'var(--fem-base)', border: '2.5px solid white', boxShadow: '0 1px 6px rgba(0,0,0,0.25), var(--fem-glow-sm)', pointerEvents: 'none' }} />
      </div>
    </div>
  );
}

function HexInput({ value, onChange }: { value: string; onChange: (hex: string) => void }) {
  const [local, setLocal] = useState(value);
  useEffect(() => setLocal(value), [value]);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ width: 26, height: 26, borderRadius: 6, background: value, border: '1px solid var(--fem-a25)', flexShrink: 0 }} />
      <input value={local} onChange={e => { setLocal(e.target.value); if (/^#[0-9a-fA-F]{6}$/.test(e.target.value)) onChange(e.target.value); }} onBlur={() => { if (!/^#[0-9a-fA-F]{6}$/.test(local)) setLocal(value); }} maxLength={7}
        style={{ width: 90, padding: '4px 8px', borderRadius: 8, background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a22)', boxShadow: 'var(--fem-inset-sm)', color: 'var(--fem-darker)', fontSize: 12, fontWeight: 600, fontFamily: 'Consolas, monospace', outline: 'none' }} />
    </div>
  );
}

function PillToggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  const [animKey, setAnimKey] = useState(0);
  return (
    <>
      <style>{`.vis-knob-anim { animation: knobPop 0.22s ease forwards; }`}</style>
      <div onClick={() => { setAnimKey(k => k + 1); onToggle(); }} style={{ width: 34, height: 18, borderRadius: 9, padding: 3, boxSizing: 'border-box', background: on ? 'var(--fem-base)' : 'var(--fem-a18)', border: `1px solid ${on ? 'var(--fem-a65)' : 'var(--fem-a30)'}`, boxShadow: on ? 'inset 0 0 8px var(--fem-a45), 0 0 6px var(--fem-a40)' : 'inset 0 0 5px var(--fem-a20)', cursor: 'pointer', transition: 'background 0.2s, border-color 0.2s, box-shadow 0.2s', display: 'flex', alignItems: 'center', justifyContent: on ? 'flex-end' : 'flex-start', flexShrink: 0 }}>
        <div key={animKey} className={animKey > 0 ? 'vis-knob-anim' : ''} style={{ width: 10, height: 10, borderRadius: '50%', background: on ? '#fff' : 'var(--fem-a30)', boxShadow: on ? '0 1px 3px rgba(0,0,0,0.2)' : 'none', transition: 'background 0.2s', flexShrink: 0 }} />
      </div>
    </>
  );
}

function ColorWheel({ hue, sat, lit, onChange }: { hue: number; sat: number; lit: number; onChange: (h: number, s: number, l: number) => void; }) {
  const SIZE = 180, RING = 18;
  const cx = SIZE / 2, inner = SIZE / 2 - RING - 4;
  const sqSize = inner * 2 * 0.707;
  const hueRef = useRef<SVGSVGElement>(null);
  const slRef  = useRef<HTMLCanvasElement>(null);
  const draggingHue = useRef(false), draggingSL = useRef(false);
  
  const getHue = useCallback((e: MouseEvent | React.MouseEvent) => { 
    const rect = hueRef.current!.getBoundingClientRect(); 
    return Math.round((Math.atan2(e.clientY - rect.top - cx, e.clientX - rect.left - cx) * 180 / Math.PI + 360 + 90) % 360); 
  }, [cx]);

  const getSL = useCallback((e: MouseEvent | React.MouseEvent) => { 
    const r = slRef.current!.getBoundingClientRect();
    const sHsv = Math.max(0, Math.min(100, ((e.clientX - r.left) / r.width) * 100));
    const vHsv = Math.max(0, Math.min(100, (1 - (e.clientY - r.top) / r.height) * 100));
    const { s, l } = hsvToHsl(hue, sHsv, vHsv);
    return { s, l }; 
  }, [hue]);

  useEffect(() => {
    const onMove = (e: MouseEvent) => { 
      if (draggingHue.current) onChange(getHue(e), sat, lit); 
      if (draggingSL.current) { const { s, l } = getSL(e); onChange(hue, s, l); } 
    };
    const onUp = () => { draggingHue.current = false; draggingSL.current = false; };
    window.addEventListener('mousemove', onMove); window.addEventListener('mouseup', onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, [hue, sat, lit, getHue, getSL, onChange]);

  useEffect(() => {
    const canvas = slRef.current; if (!canvas) return;
    const ctx = canvas.getContext('2d')!; const W = canvas.width, H = canvas.height;
    const gH = ctx.createLinearGradient(0, 0, W, 0); gH.addColorStop(0, 'hsl(0,0%,100%)'); gH.addColorStop(1, `hsl(${hue},100%,50%)`);
    ctx.fillStyle = gH; ctx.fillRect(0, 0, W, H);
    const gB = ctx.createLinearGradient(0, 0, 0, H); gB.addColorStop(0, 'rgba(0,0,0,0)'); gB.addColorStop(1, 'rgba(0,0,0,1)');
    ctx.fillStyle = gB; ctx.fillRect(0, 0, W, H);
  }, [hue]);

  const segments = 36;
  const paths = Array.from({ length: segments }, (_, i) => {
    const a1 = (i / segments) * 2 * Math.PI - Math.PI / 2, a2 = ((i + 1) / segments) * 2 * Math.PI - Math.PI / 2;
    const r1 = SIZE / 2 - RING, r2 = SIZE / 2;
    const x1=cx+r1*Math.cos(a1),y1=cx+r1*Math.sin(a1),x2=cx+r2*Math.cos(a1),y2=cx+r2*Math.sin(a1);
    const x3=cx+r2*Math.cos(a2),y3=cx+r2*Math.sin(a2),x4=cx+r1*Math.cos(a2),y4=cx+r1*Math.sin(a2);
    return { d: `M${x1} ${y1} L${x2} ${y2} A${r2} ${r2} 0 0 1 ${x3} ${y3} L${x4} ${y4} A${r1} ${r1} 0 0 0 ${x1} ${y1}Z`, hue: i * (360 / segments) };
  });

  const hRad = (hue - 90) * Math.PI / 180, hR = SIZE / 2 - RING / 2;
  const hkx = cx + hR * Math.cos(hRad), hky = cx + hR * Math.sin(hRad);
  
  const hsv = hslToHsv(hue, sat, lit);
  const slX = (hsv.s / 100) * sqSize;
  const slY = (1 - hsv.v / 100) * sqSize;

  return (
    <div style={{ position: 'relative', width: SIZE, height: SIZE, flexShrink: 0 }}>
      <svg ref={hueRef} width={SIZE} height={SIZE} style={{ position: 'absolute', inset: 0, cursor: 'crosshair' }} onMouseDown={e => { draggingHue.current = true; onChange(getHue(e), sat, lit); }}>
        {paths.map((p, i) => <path key={i} d={p.d} fill={`hsl(${p.hue},100%,55%)`} />)}
        <circle cx={hkx} cy={hky} r={8} fill={`hsl(${hue},100%,60%)`} stroke="white" strokeWidth={2.5} style={{ filter: 'drop-shadow(0 0 4px rgba(0,0,0,0.4))' }} />
      </svg>
      <div style={{ position: 'absolute', left: cx-sqSize/2, top: cx-sqSize/2, width: sqSize, height: sqSize, borderRadius: 6, overflow: 'hidden', cursor: 'crosshair', boxShadow: '0 2px 10px rgba(0,0,0,0.25)' }}>
        <canvas ref={slRef} width={sqSize} height={sqSize} style={{ display: 'block', width: sqSize, height: sqSize }} onMouseDown={e => { draggingSL.current = true; const { s, l } = getSL(e); onChange(hue, s, l); }} />
        <div style={{ position: 'absolute', left: slX-6, top: slY-6, width: 12, height: 12, borderRadius: '50%', border: '2px solid white', boxShadow: '0 0 0 1px rgba(0,0,0,0.4)', pointerEvents: 'none', background: `hsl(${hue},${sat}%,${lit}%)` }} />
      </div>
    </div>
  );
}

function ImageUploadCard({ label, currentUrl, defaultSrc, onUpload, onClear }: { label: string; currentUrl: string; defaultSrc: string; onUpload: (url: string) => void; onClear: () => void; }) {
  const [uploading, setUploading] = useState(false);
  const handleUpload = async () => { setUploading(true); const url = await pickImageAsDataUrl(); if (url) onUpload(url); setUploading(false); };
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{ width: 48, height: 48, borderRadius: 10, overflow: 'hidden', flexShrink: 0, border: '1px solid var(--fem-a25)', boxShadow: 'var(--fem-inset-sm)' }}>
        <img src={currentUrl || defaultSrc} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--fem-dark)', marginBottom: 6 }}>{label}</div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button onClick={handleUpload} disabled={uploading} style={{ padding: '4px 12px', borderRadius: 8, fontSize: 10, fontWeight: 600, cursor: uploading ? 'not-allowed' : 'pointer', fontFamily: 'inherit', background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a30)', color: 'var(--fem-muted)', boxShadow: 'var(--fem-glow-sm)', transition: 'all .15s' }}>
            {uploading ? 'Loading…' : currentUrl ? '↑ Replace' : '↑ Upload'}
          </button>
          {currentUrl && <button onClick={onClear} style={{ padding: '4px 10px', borderRadius: 8, fontSize: 10, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', background: 'transparent', border: '1px solid var(--fem-a20)', color: 'var(--fem-dim)', transition: 'all .15s' }}>Reset</button>}
        </div>
      </div>
    </div>
  );
}

const THEME_PRESETS = [
  { label: 'Pink', h: 315, s: 100, l: 75 }, { label: 'Coral', h: 10, s: 90, l: 65 },
  { label: 'Peach', h: 30, s: 90, l: 65 }, { label: 'Lemon', h: 55, s: 90, l: 65 },
  { label: 'Mint', h: 150, s: 70, l: 65 }, { label: 'Sky', h: 200, s: 85, l: 65 },
  { label: 'Blue', h: 230, s: 90, l: 70 }, { label: 'Purple', h: 270, s: 85, l: 70 },
  { label: 'Lilac', h: 290, s: 80, l: 75 }, { label: 'White', h: 0, s: 0, l: 90 },
];

interface UiPreset { label: string; hue: number; sat: number; lit: number; bgColor: string; bgImageAsset: string; logoTopAsset: string; logoBottomAsset: string; }

function PresetCard({ preset, active, onApply, onDelete }: { preset: UiPreset; active: boolean; onApply: () => void; onDelete?: () => void }) {
  const [hov, setHov] = useState(false);
  const previewColor = `hsl(${preset.hue},${preset.sat}%,${preset.lit}%)`;
  return (
    <div onClick={onApply} onMouseEnter={() => setHov(true)} onMouseLeave={() => setHov(false)}
      style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', borderRadius: 10, cursor: 'pointer', transition: 'all 0.15s', background: active ? 'var(--fem-a15)' : hov ? 'var(--fem-a08)' : 'transparent', border: `1px solid ${active ? 'var(--fem-a40)' : hov ? 'var(--fem-a22)' : 'var(--fem-a15)'}`, boxShadow: active ? 'var(--fem-inset-sm)' : 'none' }}>
      <div style={{ width: 36, height: 36, borderRadius: 8, flexShrink: 0, overflow: 'hidden', background: preset.bgColor, border: '1px solid var(--fem-a20)', position: 'relative', boxShadow: 'inset 0 0 8px rgba(0,0,0,0.1)' }}>
        {preset.logoTopAsset && <img src={preset.logoTopAsset} style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }} />}
        <div style={{ position: 'absolute', bottom: 3, right: 3, width: 10, height: 10, borderRadius: '50%', background: previewColor, boxShadow: `0 0 4px ${previewColor}`, border: '1.5px solid rgba(255,255,255,0.8)' }} />
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: active ? 'var(--fem-darker)' : 'var(--fem-dark)', transition: 'color 0.15s' }}>{preset.label}</div>
        <div style={{ fontSize: 10, color: 'var(--fem-muted)', marginTop: 2 }}>{preset.bgColor} · {previewColor}</div>
      </div>
      {active && <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--fem-base)', flexShrink: 0 }} />}
      {onDelete && <button onClick={e => { e.stopPropagation(); onDelete(); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fem-muted)', fontSize: 16, padding: '0 2px', lineHeight: 1, flexShrink: 0, marginLeft: 2 }}>×</button>}
    </div>
  );
}

// ── Mini code preview strip ───────────────────────────────────────────────────
// Updated to show all 10 token types including op and bi
function CodePreview({ c }: { c: CustomSyntaxColors }) {
  return (
    <div style={{ fontFamily: 'Consolas, monospace', fontSize: 10, lineHeight: 1.6, display: 'flex', flexDirection: 'column', gap: 1 }}>
      {/* Line 1: local RS = cloneref(game:GetService("ReplicatedStorage")) */}
      <div>
        <span style={{ color: c.kw }}>local </span>
        <span style={{ color: c.rblx }}>RS</span>
        <span style={{ color: c.op }}> = </span>
        <span style={{ color: c.bi }}>cloneref</span>
        <span style={{ color: 'var(--fem-muted)' }}>(</span>
        <span style={{ color: c.rblx }}>game</span>
        <span style={{ color: c.op }}>:</span>
        <span style={{ color: c.fn }}>GetService</span>
        <span style={{ color: 'var(--fem-muted)' }}>(</span>
        <span style={{ color: c.str }}>"ReplicatedStorage"</span>
        <span style={{ color: 'var(--fem-muted)' }}>))</span>
      </div>
      {/* Line 2: local p: Player = Players.Local -- num: 42 */}
      <div>
        <span style={{ color: c.kw }}>local </span>
        <span style={{ color: c.rblx }}>p</span>
        <span style={{ color: c.op }}>: </span>
        <span style={{ color: c.type }}>Player</span>
        <span style={{ color: c.op }}> = </span>
        <span style={{ color: c.svc }}>Players</span>
        <span style={{ color: c.op }}>.</span>
        <span style={{ color: c.rblx }}>LocalPlayer</span>
        <span style={{ color: c.op }}>  </span>
        <span style={{ color: c.cmt }}>-- score: </span>
        <span style={{ color: c.num }}>42</span>
      </div>
    </div>
  );
}

// ── Token label map — now includes op and bi ──────────────────────────────────
const TOKEN_KEYS: { key: keyof CustomSyntaxColors; label: string; desc: string }[] = [
  { key: 'kw',   label: 'Keywords',     desc: 'if · local · function · return · end' },
  { key: 'fn',   label: 'Functions',    desc: 'myFunc() · pcall() · print()' },
  { key: 'bi',   label: 'Built-ins',    desc: 'cloneref · getgenv · setmetatable · rawget' },
  { key: 'str',  label: 'Strings',      desc: '"hello" · \'world\' · [[multiline]]' },
  { key: 'num',  label: 'Numbers',      desc: '42 · 3.14 · 0xFF · 1e10' },
  { key: 'cmt',  label: 'Comments',     desc: '-- single line  ·  --[[ block ]]' },
  { key: 'op',   label: 'Operators',    desc: '= · + · - · * · / · ~ · . · ,' },
  { key: 'svc',  label: 'Services',     desc: 'ReplicatedStorage · Players · Workspace' },
  { key: 'rblx', label: 'Identifiers',  desc: 'game · CharacterAdded · myVariable' },
  { key: 'type', label: 'Types',        desc: 'string · number · boolean · Vector3' },
];

// ── Mode pill buttons ─────────────────────────────────────────────────────────
const MODES: { mode: SyntaxMode; label: string; desc: string }[] = [
  { mode: 'preset',   label: 'Presets',  desc: 'Choose a named color scheme' },
  { mode: 'custom',   label: 'Custom',   desc: 'Pick colors or auto-derive from theme' },
];

// ── Full SyntaxEditor component ───────────────────────────────────────────────
function SyntaxEditor() {
  const { theme, derived, setTheme } = useFemTheme();
  const t = theme as any;

  const mode: SyntaxMode     = t.syntaxMode   ?? DEFAULT_SYNTAX_MODE;
  const presetLabel: string  = t.syntaxTheme  ?? DEFAULT_SYNTAX_THEME;
  
  // Default colors now include op and bi
  const defaultColors: CustomSyntaxColors = (() => {
    const hslFn = (h: number, s: number, l: number) => `hsl(${h},${s}%,${l}%)`;
    const useS = derived.s;
    const useL = derived.l;
    return {
      kw:   hslFn(derived.h,        useS,          Math.max(25, useL - 5)),
      fn:   hslFn(derived.h,        useS * 0.9,    Math.min(85, useL + 10)),
      bi:   hslFn(derived.h + 25,   useS * 0.95,   Math.min(80, useL + 8)),
      str:  hslFn(derived.h,        useS * 0.8,    useL),
      num:  hslFn(derived.h,        useS * 0.7,    Math.min(80, useL + 5)),
      cmt:  hslFn(derived.h,        Math.min(useS, 25), Math.max(20, useL - 15)),
      op:   hslFn(derived.h - 10,   useS * 0.4,    Math.min(75, useL + 12)),
      svc:  hslFn(derived.h + 15,   useS * 0.85,   useL - 3),
      rblx: hslFn(derived.h + 10,   useS * 0.9,    Math.min(75, useL + 5)),
      type: hslFn(derived.h + 5,    useS * 0.75,   useL - 2),
    };
  })();

  const customColors: CustomSyntaxColors = t.syntaxColors ?? defaultColors;

  // Auto-flags default: all true (auto-derive everything from theme hue)
  const autoFlags: SyntaxAutoFlags = t.syntaxAutoFlags ?? {
    kw: true, str: true, cmt: true, num: true, fn: true,
    bi: true, op: true, svc: true, rblx: true, type: true,
  };

  const [selectedToken, setSelectedToken] = useState<keyof CustomSyntaxColors>('kw');

  const selectedHex = customColors[selectedToken] ?? '#ffffff';
  const { h: wh, s: ws, l: wl } = hexToHsl(selectedHex);
  const [wheelH, setWheelH] = useState(wh);
  const [wheelS, setWheelS] = useState(ws);
  const [wheelL, setWheelL] = useState(wl);

  const [savedSyntax, setSavedSyntax] = useState<SyntaxTheme[]>([]);
  const [newSyntaxName, setNewSyntaxName] = useState('');

  useEffect(() => { setSavedSyntax(loadSavedSyntaxSync()); }, []);

  useEffect(() => {
    const { h, s, l } = hexToHsl(customColors[selectedToken] ?? '#ffffff');
    setWheelH(s === 0 ? wheelH : h);
    setWheelS(s);
    setWheelL(l);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedToken, customColors]);

  function setMode(m: SyntaxMode) { setTheme({ syntaxMode: m } as any); }
  function setPreset(label: string) { setTheme({ syntaxTheme: label, syntaxMode: 'preset' } as any); }
  function setTokenColor(key: keyof CustomSyntaxColors, hex: string) {
    setTheme({ syntaxColors: { ...customColors, [key]: hex }, syntaxMode: 'custom' } as any);
  }

  function handleWheelChange(h: number, s: number, l: number) {
    setWheelH(h); setWheelS(s); setWheelL(l);
    setTokenColor(selectedToken, hslToHex(h, s, l));
  }

  // Live preview colors (what the editor will actually show right now)
  const preview = resolveSyntaxColors(mode, presetLabel, customColors, autoFlags, derived.h, derived.s, derived.l);
  const wheelHsv = hslToHsv(wheelH, wheelS, wheelL);

  const handleSaveSyntax = () => {
    const name = newSyntaxName.trim(); if (!name) return;
    const entry: SyntaxTheme = { label: name, ...preview };
    setSavedSyntax(prev => {
      const next = prev.filter(t => t.label !== name).concat(entry);
      persistSavedSyntax(next); return next;
    });
    setNewSyntaxName('');
    setPreset(name);
  };

  const handleDeleteSyntax = (name: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSavedSyntax(prev => {
      const next = prev.filter(t => t.label !== name);
      persistSavedSyntax(next); return next;
    });
    if (presetLabel === name) setPreset(DEFAULT_SYNTAX_THEME);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* Live preview */}
      <div style={{ padding: '10px 14px', borderRadius: 10, background: 'var(--fem-a08)', border: '1px solid var(--fem-a15)' }}>
        <div style={{ fontSize: 10, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 6 }}>Preview</div>
        <CodePreview c={preview} />
      </div>

      {/* Mode selector */}
      <div>
        <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>Mode</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          {MODES.map(({ mode: m, label, desc }) => {
            const active = mode === m;
            return (
              <button key={m} onClick={() => setMode(m)} style={{
                padding: '8px 10px', borderRadius: 10, cursor: 'pointer', textAlign: 'left',
                fontFamily: 'inherit', transition: 'all 0.15s',
                background: active ? 'var(--fem-a15)' : 'var(--fem-a08)',
                border: `1px solid ${active ? 'var(--fem-a40)' : 'var(--fem-a15)'}`,
                boxShadow: active ? 'var(--fem-inset-sm)' : 'none',
              }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: active ? 'var(--fem-darker)' : 'var(--fem-dark)', marginBottom: 2 }}>{label}</div>
                <div style={{ fontSize: 9, color: 'var(--fem-muted)', lineHeight: 1.3 }}>{desc}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Preset picker */}
      {mode === 'preset' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 2 }}>Preset</div>
          {[...SYNTAX_THEMES, ...savedSyntax].map(st => {
            const active = presetLabel === st.label;
            const isSaved = !SYNTAX_THEMES.some(builtIn => builtIn.label === st.label);
            // For 'Theme Color' preset, use auto-derived colors from current theme
            const isThemeColor = st.label === 'Theme Color';
            const c: CustomSyntaxColors = isThemeColor ? preview : {
              kw:   (st as any).kw   ?? '#888',
              fn:   (st as any).fn   ?? '#888',
              bi:   (st as any).bi   ?? '#888',
              str:  (st as any).str  ?? '#888',
              num:  (st as any).num  ?? '#888',
              cmt:  (st as any).cmt  ?? '#888',
              op:   (st as any).op   ?? '#888',
              svc:  (st as any).svc  ?? '#888',
              rblx: (st as any).rblx ?? '#888',
              type: (st as any).type ?? '#888',
            };
            return (
              <div key={st.label} onClick={() => setPreset(st.label)} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px',
                borderRadius: 10, cursor: 'pointer', transition: 'all 0.15s',
                background: active ? 'var(--fem-a15)' : 'transparent',
                border: `1px solid ${active ? 'var(--fem-a40)' : 'var(--fem-a15)'}`,
                boxShadow: active ? 'var(--fem-inset-sm)' : 'none',
              }}>
                {/* Colour chip bar — all 10 token keys */}
                <div style={{ display: 'flex', gap: 2, flexShrink: 0 }}>
                  {TOKEN_KEYS.map(({ key }) => (
                    <div key={key} style={{ width: 8, height: 26, borderRadius: 3, background: c[key] }} />
                  ))}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: active ? 'var(--fem-darker)' : 'var(--fem-dark)', marginBottom: 2 }}>{st.label}</div>
                  <CodePreview c={c} />
                </div>
                {active && <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--fem-base)', flexShrink: 0 }} />}
                {isSaved && <button onClick={(e) => handleDeleteSyntax(st.label, e)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fem-muted)', fontSize: 16, padding: '0 4px', lineHeight: 1, flexShrink: 0, marginLeft: 2 }}>×</button>}
              </div>
            );
          })}
        </div>
      )}

      {/* Custom token picker */}
      {mode === 'custom' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>Select Token</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              {TOKEN_KEYS.map(({ key, label, desc }) => {
                const active = selectedToken === key;
                const isAuto = autoFlags[key];
                const finalColor = preview[key];
                return (
                  <div key={key} onClick={() => setSelectedToken(key)} style={{
                    display: 'flex', alignItems: 'center', gap: 10, padding: '7px 10px',
                    borderRadius: 9, cursor: 'pointer', transition: 'all 0.15s',
                    background: active ? 'var(--fem-a15)' : 'var(--fem-a08)',
                    border: `1px solid ${active ? 'var(--fem-a40)' : 'var(--fem-a12)'}`,
                    boxShadow: active ? 'var(--fem-inset-sm)' : 'none',
                  }}>
                    <div style={{ width: 18, height: 18, borderRadius: 5, background: finalColor, flexShrink: 0, boxShadow: active ? `0 0 6px ${finalColor}99` : '0 1px 3px rgba(0,0,0,0.12)', transition: 'box-shadow 0.15s' }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 11, fontWeight: 600, color: active ? 'var(--fem-darker)' : 'var(--fem-dark)' }}>{label}</div>
                      <div style={{ fontSize: 9, color: 'var(--fem-muted)', marginTop: 1 }}>{desc}</div>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); setTheme({ syntaxAutoFlags: { ...autoFlags, [key]: !isAuto }, syntaxMode: 'custom' } as any); }}
                      style={{
                        padding: '3px 8px', borderRadius: 6, fontSize: 8, fontWeight: 700,
                        cursor: 'pointer', border: '1px solid',
                        background: isAuto ? 'var(--fem-base)' : 'transparent',
                        borderColor: isAuto ? 'var(--fem-base)' : 'var(--fem-a20)',
                        color: isAuto ? 'var(--fem-dark)' : 'var(--fem-muted)',
                        fontFamily: 'inherit',
                      }}
                    >
                      AUTO
                    </button>
                    <div style={{ fontSize: 9, fontFamily: 'Consolas, monospace', color: 'var(--fem-muted)', flexShrink: 0, minWidth: 60, textAlign: 'right' }}>{finalColor}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8 }}>
              Color — <span style={{ color: 'var(--fem-base)', textTransform: 'none' }}>{TOKEN_KEYS.find(t => t.key === selectedToken)?.label}</span>
            </div>
            <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', flexWrap: 'wrap' }}>
              <ColorWheel hue={wheelH} sat={wheelS} lit={wheelL} onChange={handleWheelChange} />
              <div style={{ flex: 1, minWidth: 140, display: 'flex', flexDirection: 'column', gap: 10 }}>
                <FemSlider label="Hue" value={wheelH} min={0} max={359} unit="°" onChange={h => handleWheelChange(h, wheelS, wheelL)} gradient="linear-gradient(to right,hsl(0,90%,65%),hsl(30,90%,65%),hsl(60,90%,65%),hsl(120,90%,65%),hsl(180,90%,65%),hsl(240,90%,65%),hsl(300,90%,65%),hsl(360,90%,65%))" />
                <FemSlider label="Saturation" value={Math.round(wheelHsv.s)} unit="%" onChange={s => { const hsl = hsvToHsl(wheelH, s, wheelHsv.v); handleWheelChange(wheelH, hsl.s, hsl.l); }} />
                <FemSlider label="Brightness" value={Math.round(wheelHsv.v)} unit="%" onChange={v => { const hsl = hsvToHsl(wheelH, wheelHsv.s, v); handleWheelChange(wheelH, hsl.s, hsl.l); }} />
                <div>
                  <Label>Hex</Label>
                  <HexInput value={hslToHex(wheelH, wheelS, wheelL)} onChange={hex => { const { h, s, l } = hexToHsl(hex); handleWheelChange(h, s, l); }} />
                </div>
              </div>
            </div>
          </div>

          <button onClick={() => {
            const found = [...SYNTAX_THEMES, ...savedSyntax].find(s => s.label === presetLabel) ?? SYNTAX_THEMES[0];
            // Spread all token fields from the found preset, including op and bi
            setTheme({
              syntaxColors: {
                kw:   (found as any).kw   ?? '#888',
                str:  (found as any).str  ?? '#888',
                cmt:  (found as any).cmt  ?? '#888',
                num:  (found as any).num  ?? '#888',
                fn:   (found as any).fn   ?? '#888',
                bi:   (found as any).bi   ?? '#888',
                op:   (found as any).op   ?? '#888',
                svc:  (found as any).svc  ?? '#888',
                rblx: (found as any).rblx ?? '#888',
                type: (found as any).type ?? '#888',
              },
              syntaxMode: 'custom',
            } as any);
          }} style={{ padding: '5px 12px', borderRadius: 8, fontSize: 10, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', background: 'transparent', border: '1px solid var(--fem-a20)', color: 'var(--fem-dim)', transition: 'all .15s', alignSelf: 'flex-start' }}>
            Reset from preset
          </button>
        </div>
      )}

      {/* Save Syntax Presets Input - Always visible below the editors so you can save presets anytime */}
      <div style={{ borderTop: '1px solid var(--fem-a15)', paddingTop: 14, marginTop: 4 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 6 }}>Save Syntax</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <input value={newSyntaxName} onChange={e => setNewSyntaxName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleSaveSyntax(); }} placeholder="Name this syntax preset…"
            style={{ flex: 1, padding: '6px 10px', borderRadius: 8, background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a22)', boxShadow: 'var(--fem-inset-sm)', color: 'var(--fem-darker)', fontSize: 12, fontWeight: 500, fontFamily: 'inherit', outline: 'none' }} />
          <button onClick={handleSaveSyntax} disabled={!newSyntaxName.trim()}
            style={{ padding: '6px 14px', borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: newSyntaxName.trim() ? 'pointer' : 'not-allowed', fontFamily: 'inherit', background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a30)', color: 'var(--fem-muted)', boxShadow: 'var(--fem-glow-sm)', transition: 'all .15s', opacity: newSyntaxName.trim() ? 1 : 0.5, whiteSpace: 'nowrap' }}>Save</button>
        </div>
      </div>
    </div>
  );
}

export function VisualsTab() {
  const { theme, setTheme, islandStyle } = useFemTheme();
  const [localH, setLocalH] = useState(theme.hue);
  const [localS, setLocalS] = useState(theme.sat);
  const [localL, setLocalL] = useState(theme.lit);
  const [bgH, setBgH] = useState(0);
  const [bgS, setBgS] = useState(0);
  const [bgL, setBgL] = useState(98);
  const [shadowSize,     setShadowSizeLocal]     = useState(theme.shadowSize     ?? 100);
  const [shadowStrength, setShadowStrengthLocal] = useState(theme.shadowStrength ?? 100);
  const [uploading, setUploading] = useState(false);
  const [savedThemes, setSavedThemes] = useState<SavedTheme[]>([]);
  const [newThemeName, setNewThemeName] = useState('');
  const themeCommitTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const bgCommitTimer    = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { setLocalH(theme.hue); setLocalS(theme.sat); setLocalL(theme.lit); }, [theme.hue, theme.sat, theme.lit]);
  useEffect(() => { setShadowSizeLocal(theme.shadowSize ?? 100); }, [theme.shadowSize]);
  useEffect(() => { setShadowStrengthLocal(theme.shadowStrength ?? 100); }, [theme.shadowStrength]);
  useEffect(() => { const { h, s, l } = hexToHsl(theme.bgColor); setBgH(s === 0 ? bgH : h); setBgS(s); setBgL(l); }, [theme.bgColor, bgH]);
  useEffect(() => { setSavedThemes(loadSavedThemesSync()); }, []);

  const handleSaveTheme = useCallback(() => {
    const name = newThemeName.trim(); if (!name) return;
    const entry: SavedTheme = { name, theme: { ...theme }, savedAt: Date.now() };
    setSavedThemes(prev => { const existing = prev.findIndex(t => t.name === name); const next = existing >= 0 ? prev.map((t, i) => i === existing ? entry : t) : [...prev, entry]; persistSavedThemes(next); return next; });
    setNewThemeName('');
  }, [theme, newThemeName]);

  const handleLoadTheme = useCallback((saved: SavedTheme) => {
    const t = saved.theme as any;
    if (t.hue !== undefined && t.sat !== undefined && t.lit !== undefined) { setLocalH(t.hue); setLocalS(t.sat); setLocalL(t.lit); }
    if (t.shadowSize     !== undefined) setShadowSizeLocal(t.shadowSize);
    if (t.shadowStrength !== undefined) setShadowStrengthLocal(t.shadowStrength);
    setTheme(t);
  }, [setTheme]);

  const handleDeleteTheme = useCallback((name: string) => {
    setSavedThemes(prev => { const next = prev.filter(t => t.name !== name); persistSavedThemes(next); return next; });
  }, []);

  const handleThemeColorChange = useCallback((h: number, s: number, l: number) => {
    setLocalH(h); setLocalS(s); setLocalL(l);
    if (themeCommitTimer.current) clearTimeout(themeCommitTimer.current);
    themeCommitTimer.current = setTimeout(() => setTheme({ hue: h, sat: s, lit: l }), 40);
  }, [setTheme]);

  const handleBgColorChange = useCallback((h: number, s: number, l: number) => {
    setBgH(h); setBgS(s); setBgL(l);
    if (bgCommitTimer.current) clearTimeout(bgCommitTimer.current);
    bgCommitTimer.current = setTimeout(() => setTheme({ bgColor: hslToHex(h, s, l) }), 40);
  }, [setTheme]);

  const handleUploadBg = useCallback(async () => {
    setUploading(true);
    const url = await pickImageAsDataUrl();
    if (url) setTheme({ bgImageUrl: url, bgMode: 'image', presetName: '' } as any);
    setUploading(false);
  }, [setTheme]);

  const UI_PRESETS: UiPreset[] = [
    { label: 'Astolfo', hue: 315, sat: 100, lit: 75, bgColor: '#fff5fb', bgImageAsset: astolfoAsset, logoTopAsset: topImgDefault, logoBottomAsset: bottomImgDefault },
    { label: 'Boy Kisser', hue: 0, sat: 0, lit: 28, bgColor: '#d1d1d1', bgImageAsset: boyKisserBg, logoTopAsset: boyKisserTop, logoBottomAsset: boyKisserBottom },
  ];

  const activePresetLabel = (theme as any).presetName || null;

  const applyPreset = useCallback((preset: UiPreset) => {
    setLocalH(preset.hue); setLocalS(preset.sat); setLocalL(preset.lit);
    setShadowSizeLocal(100);
    setShadowStrengthLocal(100);
    setTheme({
      hue: preset.hue, sat: preset.sat, lit: preset.lit,
      bgColor: preset.bgColor,
      bgImageUrl: '',
      bgMode: 'image',
      logoTopUrl: '',
      logoBottomUrl: '',
      presetName: preset.label,
      fgOpacity: 60,
      bgOpacity: 60,
      shadowSize: 100,
      shadowStrength: 100,
      syntaxTheme: 'Theme Color',
      syntaxMode: 'preset',
      syntaxColors: {
        kw:   '#7eb8f7',
        str:  '#f4a97f',
        cmt:  '#81c784',
        num:  '#c49ef5',
        fn:   '#7ee8f7',
        bi:   '#d7a4f0',
        op:   '#c0c8d8',
        svc:  '#4EC9B0',
        rblx: '#9CDCFE',
        type: '#4EC9B0',
      },
    } as any);
  }, [setTheme]);

  const bgImageEnabled = theme.bgMode === 'image' && !!(theme.bgImageUrl || (theme as any).presetName);
  const currentThemeHex = hslToHex(localH, localS, localL);
  const currentBgHex    = hslToHex(bgH, bgS, bgL);
  const previewColor    = `hsl(${localH},${localS}%,${localL}%)`;

  const localHsv = hslToHsv(localH, localS, localL);
  const bgHsv    = hslToHsv(bgH, bgS, bgL);

  return (
    <div style={{ ...islandStyle, flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minHeight: 0, minWidth: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '0 16px', height: 44, flexShrink: 0, borderBottom: '1px solid var(--fem-a15)' }}>
        <span style={{ color: 'var(--fem-dark)', fontSize: 13, fontWeight: 600 }}>Visuals</span>
        <div style={{ marginLeft: 10, width: 12, height: 12, borderRadius: '50%', background: previewColor, boxShadow: `0 0 8px ${previewColor}`, border: '1.5px solid rgba(255,255,255,0.6)' }} />
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '14px 14px 20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Section title="Presets">
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {UI_PRESETS.map(preset => (
              <PresetCard key={preset.label} preset={preset} active={activePresetLabel === preset.label} onApply={() => applyPreset(preset)} />
            ))}
            {savedThemes.map(saved => {
              const t = saved.theme as any;
              const asPreset: UiPreset = { label: saved.name, hue: t.hue ?? 315, sat: t.sat ?? 100, lit: t.lit ?? 75, bgColor: t.bgColor ?? '#fff5fb', bgImageAsset: t.bgImageUrl ?? '', logoTopAsset: t.logoTopUrl ?? '', logoBottomAsset: t.logoBottomUrl ?? '' };
              const isActive = theme.hue === asPreset.hue && theme.sat === asPreset.sat && theme.lit === asPreset.lit && theme.bgColor === asPreset.bgColor;
              return <PresetCard key={saved.name} preset={asPreset} active={isActive} onApply={() => handleLoadTheme(saved)} onDelete={() => handleDeleteTheme(saved.name)} />;
            })}
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: savedThemes.length > 0 ? 4 : 0 }}>
            <input value={newThemeName} onChange={e => setNewThemeName(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') handleSaveTheme(); }} placeholder="Save current theme as preset…"
              style={{ flex: 1, padding: '6px 10px', borderRadius: 8, background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a22)', boxShadow: 'var(--fem-inset-sm)', color: 'var(--fem-darker)', fontSize: 12, fontWeight: 500, fontFamily: 'inherit', outline: 'none' }} />
            <button onClick={handleSaveTheme} disabled={!newThemeName.trim()}
              style={{ padding: '6px 14px', borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: newThemeName.trim() ? 'pointer' : 'not-allowed', fontFamily: 'inherit', background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a30)', color: 'var(--fem-muted)', boxShadow: 'var(--fem-glow-sm)', transition: 'all .15s', opacity: newThemeName.trim() ? 1 : 0.5, whiteSpace: 'nowrap' }}>Save</button>
          </div>
        </Section>

        <CollapsibleSection title="Theme Color" defaultOpen={false}>
          <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <ColorWheel hue={localH} sat={localS} lit={localL} onChange={handleThemeColorChange} />
            <div style={{ flex: 1, minWidth: 160, display: 'flex', flexDirection: 'column', gap: 14 }}>
              <FemSlider label="Hue" value={localH} min={0} max={359} unit="°" onChange={h => handleThemeColorChange(h, localS, localL)} gradient="linear-gradient(to right,hsl(0,90%,65%),hsl(30,90%,65%),hsl(60,90%,65%),hsl(120,90%,65%),hsl(180,90%,65%),hsl(240,90%,65%),hsl(300,90%,65%),hsl(360,90%,65%))" />
              <FemSlider label="Saturation" value={Math.round(localHsv.s)} unit="%" onChange={s => { const hsl = hsvToHsl(localH, s, localHsv.v); handleThemeColorChange(localH, hsl.s, hsl.l); }} />
              <FemSlider label="Brightness" value={Math.round(localHsv.v)} unit="%" onChange={v => { const hsl = hsvToHsl(localH, localHsv.s, v); handleThemeColorChange(localH, hsl.s, hsl.l); }} />
              <div><Label>Hex</Label><HexInput value={currentThemeHex} onChange={hex => { const { h, s, l } = hexToHsl(hex); handleThemeColorChange(h, s, l); }} /></div>
            </div>
          </div>
          <div style={{ borderTop: '1px solid var(--fem-a15)', paddingTop: 14, display: 'flex', flexDirection: 'column', gap: 14 }}>
            <FemSlider
              label="Shadow Size"
              value={shadowSize}
              min={0}
              max={200}
              unit=""
              onChange={v => { setShadowSizeLocal(v); setTheme({ shadowSize: v }); }}
            />
            <FemSlider
              label="Shadow Strength"
              value={shadowStrength}
              min={0}
              max={200}
              unit="%"
              onChange={v => { setShadowStrengthLocal(v); setTheme({ shadowStrength: v }); }}
            />
            <FemSlider label="Panel Opacity" value={theme.fgOpacity} unit="%" onChange={v => setTheme({ fgOpacity: v })} />
          </div>
        </CollapsibleSection>

        <CollapsibleSection title="Background Color" defaultOpen={false}>
          <div style={{ display: 'flex', gap: 20, alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <ColorWheel hue={bgH} sat={bgS} lit={bgL} onChange={handleBgColorChange} />
            <div style={{ flex: 1, minWidth: 160, display: 'flex', flexDirection: 'column', gap: 14 }}>
              <FemSlider label="Hue" value={bgH} min={0} max={359} unit="°" onChange={h => handleBgColorChange(h, bgS, bgL)} gradient="linear-gradient(to right,hsl(0,90%,65%),hsl(30,90%,65%),hsl(60,90%,65%),hsl(120,90%,65%),hsl(180,90%,65%),hsl(240,90%,65%),hsl(300,90%,65%),hsl(360,90%,65%))" />
              <FemSlider label="Saturation" value={Math.round(bgHsv.s)} unit="%" onChange={s => { const hsl = hsvToHsl(bgH, s, bgHsv.v); handleBgColorChange(bgH, hsl.s, hsl.l); }} />
              <FemSlider label="Brightness" value={Math.round(bgHsv.v)} unit="%" onChange={v => { const hsl = hsvToHsl(bgH, bgHsv.s, v); handleBgColorChange(bgH, hsl.s, hsl.l); }} />
              <div><Label>Hex</Label><HexInput value={currentBgHex} onChange={hex => { const { h, s, l } = hexToHsl(hex); handleBgColorChange(h, s, l); }} /></div>
              <div>
                <Label>Quick picks</Label>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {[{ label: 'Soft Pink', c: '#fff5fb' },{ label: 'White', c: '#ffffff' },{ label: 'Off-White', c: '#fafafa' },{ label: 'Lavender', c: '#f5f0ff' },{ label: 'Dark Navy', c: '#1a1a2e' },{ label: 'Deep Dark', c: '#0f0f23' },{ label: 'Dark Rose', c: '#1a0a2e' },{ label: 'Charcoal', c: '#16213e' }].map(({ label: lbl, c }) => (
                    <button key={c} title={lbl} onClick={() => { const { h, s, l } = hexToHsl(c); handleBgColorChange(h, s, l); }} style={{ width: 24, height: 24, borderRadius: 5, border: 'none', background: c, cursor: 'pointer', flexShrink: 0, boxShadow: theme.bgColor === c ? '0 0 0 2px white, 0 0 0 3.5px var(--fem-base)' : '0 1px 4px rgba(0,0,0,0.15)', transition: 'box-shadow .15s' }} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </CollapsibleSection>

        <CollapsibleSection title="App Icons & Background Image" defaultOpen={true}>
          <ImageUploadCard label="Top-Left Logo" currentUrl={theme.logoTopUrl} defaultSrc={topImgDefault} onUpload={url => setTheme({ logoTopUrl: url, presetName: '' } as any)} onClear={() => setTheme({ logoTopUrl: '' })} />
          <ImageUploadCard label="Bottom-Left Avatar" currentUrl={theme.logoBottomUrl} defaultSrc={bottomImgDefault} onUpload={url => setTheme({ logoBottomUrl: url, presetName: '' } as any)} onClear={() => setTheme({ logoBottomUrl: '' })} />
          <div style={{ borderTop: '1px solid var(--fem-a15)', paddingTop: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
              <Label>Background Image</Label>
              <PillToggle on={bgImageEnabled} onToggle={() => { if (bgImageEnabled) { setTheme({ bgMode: 'color', presetName: '' } as any); } else if (theme.bgImageUrl) { setTheme({ bgMode: 'image' }); } else { handleUploadBg(); } }} />
            </div>
            {theme.bgImageUrl ? (
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <div style={{ width: 80, flexShrink: 0, borderRadius: 10, overflow: 'hidden', border: '1px solid var(--fem-a25)', boxShadow: 'var(--fem-inset-sm)', opacity: bgImageEnabled ? 1 : 0.4, transition: 'opacity 0.2s' }}>
                  <img src={theme.bgImageUrl} style={{ width: '100%', height: 'auto', display: 'block' }} />
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <button onClick={handleUploadBg} disabled={uploading} style={{ padding: '4px 12px', borderRadius: 8, fontSize: 10, fontWeight: 600, cursor: uploading ? 'not-allowed' : 'pointer', fontFamily: 'inherit', background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a30)', color: 'var(--fem-muted)', boxShadow: 'var(--fem-glow-sm)', transition: 'all .15s', opacity: uploading ? 0.6 : 1 }}>{uploading ? 'Loading…' : '↑ Replace'}</button>
                  <button onClick={() => setTheme({ bgImageUrl: '', bgMode: 'color', presetName: '' } as any)} style={{ padding: '4px 10px', borderRadius: 8, fontSize: 10, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', background: 'transparent', border: '1px solid var(--fem-a20)', color: 'var(--fem-dim)', transition: 'all .15s' }}>Remove</button>
                </div>
              </div>
            ) : (
              <button onClick={handleUploadBg} disabled={uploading} style={{ padding: '6px 14px', borderRadius: 8, fontSize: 11, fontWeight: 600, cursor: uploading ? 'not-allowed' : 'pointer', fontFamily: 'inherit', background: 'var(--fem-island-bg)', border: '1px solid var(--fem-a30)', color: 'var(--fem-muted)', boxShadow: 'var(--fem-glow-sm)', transition: 'all .15s', opacity: uploading ? 0.6 : 1 }}>{uploading ? 'Loading…' : '↑ Upload Image'}</button>
            )}
            {bgImageEnabled && <div style={{ marginTop: 10 }}><FemSlider label="Image Opacity" value={theme.bgOpacity} unit="%" onChange={v => setTheme({ bgOpacity: v })} /></div>}
          </div>
        </CollapsibleSection>

        {/* ── SYNTAX THEME ─────────────────────────────────────────────────── */}
        <CollapsibleSection title="Syntax Colors" defaultOpen={false}>
          <SyntaxEditor />
        </CollapsibleSection>

        {/* Reset to default — now includes op and bi in the reset payload */}
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button onClick={() => {
            handleThemeColorChange(315, 100, 75);
            setShadowSizeLocal(100);
            setShadowStrengthLocal(100);
            setTheme({
              bgColor: '#fff5fb',
              bgMode: 'color',
              bgImageUrl: '',
              fgOpacity: 100,
              bgOpacity: 100,
              shadowSize: 100,
              shadowStrength: 100,
              logoTopUrl: '',
              logoBottomUrl: '',
              presetName: '',
              syntaxTheme: DEFAULT_SYNTAX_THEME,
              syntaxMode: DEFAULT_SYNTAX_MODE,
              syntaxColors: {
                kw:   '#7eb8f7',
                str:  '#f4a97f',
                cmt:  '#81c784',
                num:  '#c49ef5',
                fn:   '#7ee8f7',
                bi:   '#d7a4f0',
                op:   '#c0c8d8',
                svc:  '#4EC9B0',
                rblx: '#9CDCFE',
                type: '#4EC9B0',
              },
            } as any);
          }}
            style={{ padding: '6px 16px', borderRadius: 10, fontSize: 10, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', background: 'transparent', border: '1px solid var(--fem-a20)', color: 'var(--fem-dim)', transition: 'all .15s' }}>
            Reset to default
          </button>
        </div>
      </div>
    </div>
  );
}