﻿import { useState, useRef, useEffect, useCallback } from 'react';
import { invoke } from '@tauri-apps/api/core';
import { open, save } from '@tauri-apps/plugin-dialog';
import { readTextFile, writeTextFile } from '@tauri-apps/plugin-fs';
import { listen } from '@tauri-apps/api/event';
import { getAttachState, getProcesses, subscribeAttach, refreshProcesses, getSelectedPids, setAttachedState, startAttaching, setDetached, getAttachedProcesses } from '../../stores/attachStore';
import { appendConsoleLog, clearConsoleLogs, getConsoleLogs, subscribeToConsoleLogs } from '../../stores/consoleStore';
import { loadTabs, saveTabs } from '../../stores/tabsStore';
import { setSession, removeSession, getSessions } from '../../stores/instanceSessionStore';
import { fileStore, subscribeToFileStore, initializeFileStore, ScriptTreeNode } from '../../stores/fileStore';
import { useFemTheme } from '../../context/themeContext';
import { resolveSyntaxColors, DEFAULT_SYNTAX_THEME, DEFAULT_SYNTAX_MODE } from '../../constants/syntaxThemes';
import { CodeEditor } from '../../editor/CodeEditor';

import sidebarIcon   from '../../assets/sidebar.png?inline';
import downArrowIcon from '../../assets/down-arrow.png?inline';
import folderIcon    from '../../assets/folder.png?inline';
import branchIcon    from '../../assets/branch.png?inline';
import cloudIcon     from '../../assets/fem-cloud.png?inline';
import blankPageIcon from '../../assets/blank-page.png?inline';

interface FileTab     { id: number; name: string; content: string; }
interface ScriptEntry { id: number; name: string; content: string; }
interface FavoriteEntry { id: string; name: string; content: string; addedAt: number; }
interface Props { sidebarOpen: boolean; setSidebarOpen: (v: boolean | ((p: boolean) => boolean)) => void; }

const FAVORITES_STORAGE_KEY = 'femware-favorites-v1';

const DEFAULT_TAB_ID = 0;
const DEFAULT_TAB: FileTab = { id: DEFAULT_TAB_ID, name: 'Untitled', content: '' };

function loadFavorites(): FavoriteEntry[] {
  try {
    const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
    if (raw) return JSON.parse(raw) as FavoriteEntry[];
  } catch {}
  return [];
}
function saveFavorites(favs: FavoriteEntry[]) {
  try { localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(favs)); } catch {}
}

function Icon({ src, size, active }: { src: string; size: number; active?: boolean }) {
  return (
    <div style={{
      width: size, height: size, flexShrink: 0,
      backgroundColor: active ? 'var(--fem-base)' : 'var(--fem-muted)',
      WebkitMaskImage: `url(${src})`,
      WebkitMaskSize: 'contain',
      WebkitMaskRepeat: 'no-repeat',
      WebkitMaskPosition: 'center',
      maskImage: `url(${src})`,
      maskSize: 'contain',
      maskRepeat: 'no-repeat',
      maskPosition: 'center',
      pointerEvents: 'none',
      transition: 'background-color 0.2s',
    }} />
  );
}

function AddItemModal({ parentPath, onConfirm, onCancel }: {
  parentPath: string;
  onConfirm: (name: string, type: 'file' | 'folder') => void;
  onCancel: () => void;
}) {
  const { islandStyle, derived, theme } = useFemTheme();
  const [type, setType] = useState<'file' | 'folder'>('file');
  const [name, setName] = useState('script');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
    inputRef.current?.select();
  }, []);

  const handleTypeChange = (t: 'file' | 'folder') => {
    setType(t);
    setName(t === 'file' ? 'script' : 'New Folder');
    setTimeout(() => { inputRef.current?.focus(); inputRef.current?.select(); }, 0);
  };

  const handleConfirm = () => {
    const trimmed = name.trim();
    if (!trimmed) return;
    let finalName = trimmed;
    if (type === 'file') {
      finalName = trimmed.replace(/\.(lua|luau|txt)$/i, '') + '.lua';
    }
    onConfirm(finalName, type);
  };

  return (
    <div
      style={{
        position: 'fixed', inset: 0,
        background: 'rgba(0,0,0,0.55)', zIndex: 10000,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}
      onClick={onCancel}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          ...islandStyle,
          padding: '18px 18px',
          minWidth: 290,
          borderRadius: 14,
          display: 'flex',
          flexDirection: 'column',
          gap: 10,
          background: theme.bgColor,
          opacity: 1,
        }}
      >
        <div style={{ display: 'flex', gap: 6 }}>
          {(['file', 'folder'] as const).map(t => (
            <button
              key={t}
              onClick={() => handleTypeChange(t)}
              style={{
                flex: 1, height: 30, borderRadius: 8,
                fontSize: 12, fontWeight: 500, cursor: 'pointer',
                fontFamily: 'inherit',
                background: type === t ? derived.a20 : derived.a08,
                border: `1px solid ${type === t ? derived.a40 : derived.a20}`,
                color: type === t ? 'var(--fem-base)' : 'var(--fem-muted)',
                boxShadow: type === t ? 'var(--fem-inset-md)' : 'none',
                transition: 'all .15s',
              }}
            >
              {t === 'file' ? 'Script' : 'Folder'}
            </button>
          ))}
        </div>

        {parentPath && (
          <div style={{ color: 'var(--fem-muted)', fontSize: 11, opacity: 0.7 }}>
            Inside: {parentPath}
          </div>
        )}

        <input
          ref={inputRef}
          value={name}
          onChange={e => setName(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter') handleConfirm();
            if (e.key === 'Escape') onCancel();
          }}
          placeholder={type === 'file' ? 'script name' : 'folder name'}
          style={{
            width: '100%', boxSizing: 'border-box',
            background: derived.a08,
            border: `1px solid ${derived.a30}`,
            borderRadius: 8, padding: '8px 10px',
            color: 'var(--fem-darker)', fontSize: 12,
            fontFamily: 'inherit', outline: 'none',
            caretColor: 'var(--fem-base)',
            boxShadow: 'var(--fem-inset-md)',
          }}
        />

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button
            onClick={onCancel}
            style={{
              padding: '0 14px', height: 32, borderRadius: 10,
              fontSize: 12, fontWeight: 500, cursor: 'pointer',
              fontFamily: 'inherit',
              background: derived.a08,
              border: `1px solid ${derived.a30}`,
              color: 'var(--fem-muted)',
              transition: 'all .15s',
            }}
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            style={{
              padding: '0 14px', height: 32, borderRadius: 10,
              fontSize: 12, fontWeight: 500, cursor: 'pointer',
              fontFamily: 'inherit',
              background: derived.a08,
              border: `1px solid ${derived.a30}`,
              color: 'var(--fem-base)',
              boxShadow: 'var(--fem-glow-sm)',
              transition: 'all .15s',
            }}
          >
            Create
          </button>
        </div>
      </div>
    </div>
  );
}

function AccordionSection({ label, icon, isOpen, onToggle, headerExtra, children }: {
  label: string; icon?: string; isOpen?: boolean;
  onToggle?: (open: boolean) => void;
  headerExtra?: React.ReactNode;
  children?: React.ReactNode;
}) {
  const { derived } = useFemTheme();
  const [internalOpen, setInternalOpen] = useState(false);
  const open = isOpen ?? internalOpen;
  const handleToggle = (v: boolean) => { if (onToggle) onToggle(v); else setInternalOpen(v); };

  return (
    <div style={{ marginBottom: 4, marginTop: 8 }}>
      <button
        onClick={() => handleToggle(!open)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '10px 10px', border: '1px solid var(--fem-a30)', borderRadius: 12,
          fontFamily: 'inherit', fontSize: 12, fontWeight: 500, cursor: 'pointer', transition: 'all .2s',
          background: derived.islandBg,
          boxShadow: open ? 'var(--fem-inset-md)' : 'var(--fem-glow-sm)',
        }}
      >
        <span style={{ display: 'flex', alignItems: 'center', gap: 8, color: open ? 'var(--fem-darker)' : 'var(--fem-muted)' }}>
          {icon && <Icon src={icon} size={16} active={open} />}
          <span>{label}</span>
        </span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          {headerExtra && (
            <div onClick={e => e.stopPropagation()} style={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              {headerExtra}
            </div>
          )}
          <div style={{
            width: 16, height: 16, flexShrink: 0,
            backgroundColor: open ? 'var(--fem-base)' : 'var(--fem-muted)',
            WebkitMaskImage: `url(${downArrowIcon})`,
            WebkitMaskSize: 'contain', WebkitMaskRepeat: 'no-repeat', WebkitMaskPosition: 'center',
            maskImage: `url(${downArrowIcon})`,
            maskSize: 'contain', maskRepeat: 'no-repeat', maskPosition: 'center',
            borderRadius: 3,
            transform: open ? '' : 'rotate(180deg)',
            transition: 'background-color 0.2s, transform 0.25s',
            pointerEvents: 'none',
          }} />
        </div>
      </button>
      {open && <div style={{ padding: '4px 0' }}>{children}</div>}
    </div>
  );
}

function ScriptRow({ name, selected, onSelect, onDelete }: {
  name: string; selected: boolean; onSelect: () => void; onDelete?: () => void;
}) {
  const { derived } = useFemTheme();
  const [hov, setHov] = useState(false);
  return (
    <div
      onClick={onSelect}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '5px 10px', cursor: 'pointer', borderRadius: 6,
        fontSize: 12, fontWeight: 500, transition: 'all .15s',
        color: selected ? 'var(--fem-darker)' : hov ? 'var(--fem-dark)' : 'var(--fem-dim)',
        background: selected ? derived.islandBg : hov ? derived.a08 : 'transparent',
        boxShadow: selected ? `inset 0 0 12px ${derived.a40}` : hov ? `inset 0 0 8px ${derived.a28}` : 'none',
        border: selected ? `1px solid ${derived.a20}` : '1px solid transparent',
      }}
    >
      <span style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 0, overflow: 'hidden' }}>
        <Icon src={blankPageIcon} size={13} active={selected || hov} />
        <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{name}</span>
      </span>
      {onDelete && (
        <button
          onClick={e => { e.stopPropagation(); onDelete(); }}
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fem-muted)', fontSize: 14, padding: '0 2px', marginLeft: 4, lineHeight: 1, flexShrink: 0 }}
        >×</button>
      )}
    </div>
  );
}

function FolderTreeNode({
  node, depth, activeFileId, onOpenFile, onDelete, onAddInside,
  onDragStart, onDragOver, onDrop, draggingId,
}: {
  node: ScriptTreeNode;
  depth: number;
  activeFileId: string | null;
  onOpenFile: (node: ScriptTreeNode) => void;
  onDelete: (node: ScriptTreeNode) => void;
  onAddInside: (parentPath: string) => void;
  onDragStart: (id: string) => void;
  onDragOver: (e: React.DragEvent, id: string) => void;
  onDrop: (e: React.DragEvent, targetId: string) => void;
  draggingId: string | null;
}) {
  const { derived } = useFemTheme();
  const [expanded, setExpanded] = useState(true);
  const [hov, setHov] = useState(false);
  const [dropHov, setDropHov] = useState(false);

  if (node.isDir) {
    return (
      <div
        style={{ paddingLeft: depth > 0 ? 10 : 0 }}
        onDragOver={e => { e.preventDefault(); setDropHov(true); onDragOver(e, node.id); }}
        onDragLeave={() => setDropHov(false)}
        onDrop={e => { setDropHov(false); onDrop(e, node.id); }}
      >
        <div
          onMouseEnter={() => setHov(true)}
          onMouseLeave={() => setHov(false)}
          draggable
          onDragStart={() => onDragStart(node.id)}
          style={{
            display: 'flex', alignItems: 'center', gap: 5,
            padding: '5px 6px 5px 8px', cursor: 'grab', borderRadius: 6,
            fontSize: 12, fontWeight: 500, transition: 'all .15s',
            color: expanded ? 'var(--fem-darker)' : hov ? 'var(--fem-dark)' : 'var(--fem-dim)',
            background: dropHov ? derived.a08 : hov ? derived.a08 : 'transparent',
            border: dropHov ? `1px solid ${derived.a30}` : '1px solid transparent',
            boxShadow: expanded ? `inset 0 0 12px ${derived.a40}` : 'none',
            opacity: draggingId === node.id ? 0.4 : 1,
          }}
        >
          <div
            onClick={() => setExpanded(v => !v)}
            style={{
              width: 12, height: 12, flexShrink: 0, display: 'flex',
              alignItems: 'center', justifyContent: 'center',
              color: expanded ? 'var(--fem-base)' : 'var(--fem-muted)', fontSize: 9, userSelect: 'none',
              transform: expanded ? 'rotate(0deg)' : 'rotate(-90deg)',
              transition: 'background-color 0.2s, transform 0.2s',
            }}
          >▼</div>
          <div onClick={() => setExpanded(v => !v)} style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 0, overflow: 'hidden' }}>
            <Icon src={folderIcon} size={13} active={expanded || hov} />
            <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{node.name}</span>
          </div>
          {hov && (
            <div style={{ display: 'flex', gap: 2, flexShrink: 0 }}>
              <button
                title="New item inside"
                onClick={e => { e.stopPropagation(); onAddInside(node.relativePath); }}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fem-muted)', fontSize: 13, padding: '0 3px', lineHeight: 1 }}
              >+</button>
              <button
                title="Delete folder"
                onClick={e => { e.stopPropagation(); onDelete(node); }}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fem-muted)', fontSize: 14, padding: '0 2px', marginLeft: 2, lineHeight: 1 }}
              >×</button>
            </div>
          )}
        </div>

        {expanded && (
          <div style={{ borderLeft: `1px solid ${derived.a20}`, marginLeft: 14, paddingLeft: 4 }}>
            {(node.children ?? []).length === 0 && (
              <p style={{ color: 'var(--fem-muted)', fontSize: 11, margin: '4px 8px', opacity: 0.6 }}>Empty folder</p>
            )}
            {(node.children ?? []).map(child => (
              <FolderTreeNode
                key={child.id}
                node={child}
                depth={depth + 1}
                activeFileId={activeFileId}
                onOpenFile={onOpenFile}
                onDelete={onDelete}
                onAddInside={onAddInside}
                onDragStart={onDragStart}
                onDragOver={onDragOver}
                onDrop={onDrop}
                draggingId={draggingId}
              />
            ))}
          </div>
        )}
      </div>
    );
  }

  const isSelected = node.fileId === activeFileId;
  return (
    <div
      style={{ paddingLeft: depth > 0 ? 10 : 0, opacity: draggingId === node.id ? 0.4 : 1 }}
      draggable
      onDragStart={() => onDragStart(node.id)}
      onDragOver={e => { e.preventDefault(); onDragOver(e, node.id); }}
      onDrop={e => onDrop(e, node.id)}
    >
      <ScriptRow
        name={node.name}
        selected={isSelected}
        onSelect={() => onOpenFile(node)}
        onDelete={() => onDelete(node)}
      />
    </div>
  );
}

function ActionBtn({ label, onClick, disabled }: {
  label: string; primary?: boolean; onClick?: () => void; disabled?: boolean;
}) {
  const { derived } = useFemTheme();
  const [hov, setHov]       = useState(false);
  const [active, setActive] = useState(false);
  return (
    <button
      onClick={onClick} disabled={disabled}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => { setHov(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={{
        padding: '0 14px', height: 36, borderRadius: 12,
        fontSize: 12, fontWeight: 500, cursor: disabled ? 'not-allowed' : 'pointer',
        fontFamily: 'inherit', transition: 'all .15s',
        color: (hov || active) ? 'var(--fem-base)' : 'var(--fem-muted)',
        background: derived.islandBg,
        border: '1px solid var(--fem-a30)',
        boxShadow: active ? 'var(--fem-inset-md)' : 'var(--fem-glow-sm)',
        opacity: disabled ? 0.6 : 1, whiteSpace: 'nowrap',
      }}
    >{label}</button>
  );
}

export function EditorTab({ sidebarOpen, setSidebarOpen }: Props) {
  const { islandStyle, derived, theme } = useFemTheme();

  // Async dynamic Autoexec lookup path state (clears hardcoded directory dependency)
  const [autoexecPath, setAutoexecPath] = useState<string>('');
  const [loading, setLoading] = useState(true);

  const addLog = useCallback((level: string, message: string) => {
    const v = ['info','warning','error','success','status'].includes(level) ? level as any : 'info';
    appendConsoleLog({ level: v, message, source: 'femware' });
  }, []);

  const t = theme as any;
  const activeSyntaxTheme = resolveSyntaxColors(
    t.syntaxMode  ?? DEFAULT_SYNTAX_MODE,
    t.syntaxTheme ?? DEFAULT_SYNTAX_THEME,
    t.syntaxColors ?? null,
    t.syntaxAutoFlags ?? null,
    derived.h, derived.s, derived.l,
  );

  const [tabs, setTabs]               = useState<FileTab[]>([DEFAULT_TAB]);
  const [activeTabId, setActiveTabId] = useState(DEFAULT_TAB_ID);

  const [madiumConnected, setMadiumConnected] = useState(false);

  useEffect(() => {
    // Dynamically retrieve real Auto-Exec path
    invoke<string>('get_autoexec_path').then(path => {
      setAutoexecPath(path);
    });

    loadTabs().then(state => {
      const loadedTabs = state.tabs.length > 0 ? state.tabs : [DEFAULT_TAB];
      const loadedActiveId = loadedTabs.find(t => t.id === state.activeTabId)
        ? state.activeTabId
        : loadedTabs[0].id;
      setTabs(loadedTabs);
      setActiveTabId(loadedActiveId);
      setSidebarWidth(state.sidebarWidth);
      setConsoleHeight(state.consoleHeight);
      setAccordionOpen(state.accordionOpen);
      setLoading(false);
    });

    const madiumPoll = setInterval(async () => {
      try {
        const isConnected = await invoke<boolean>('is_madium_connected');
        setMadiumConnected(isConnected);

        if (!isConnected && getAttachState() === 'attached') {
          setAttachedState(false, []);
          addLog('warning', 'Roblox process closed / disconnected.');
        }
      } catch {}
    }, 1000);
    return () => clearInterval(madiumPoll);
  }, []);

  useEffect(() => {
    let active = true;

    const initHandshake = async () => {
      const unlistenHandshake = await listen<any>('madium-handshake', async (event) => {
        if (!active) return;
        const data = event.payload;
        try {
          const realPid = Number(data.connId);
          const avatarUrl = await invoke<string>('fetch_roblox_avatar', { userId: data.userId });

          setSession(realPid, {
            pid: realPid,
            username: data.username,
            displayName: data.displayName,
            gameName: data.gameName,
            gameId: data.gameId,
            jobId: data.jobId,
            userId: data.userId,
            avatarUrl: avatarUrl,
          });

          setAttachedState(true, [realPid]);
          addLog('success', `Successfully attached: ${data.username} [${data.gameName}]`);
        } catch (err) {
          console.error('Failed parsing handshake meta:', err);
          const mockPid = Date.now();
          setAttachedState(true, [mockPid]);
          addLog('success', 'Successfully attached to instance');
        }
      });

      const unlistenDisconnect = await listen<any>('madium-disconnect', async (event) => {
        if (!active) return;
        const payload = event.payload;
        
        if (payload && payload.userId) {
          const pid = Number(payload.userId);
          
          const currentSessions = getSessions();
          const session = currentSessions[pid];
          const username = session ? session.username : `PID ${pid}`;

          removeSession(pid);
          setAttachedState(false, [pid]);
          
          addLog('warning', `Detached / Closed: ${username}`);
        } else {
          setAttachedState(false, []);
          addLog('warning', 'Roblox process closed / disconnected.');
        }
      });

      return { unlistenHandshake, unlistenDisconnect };
    };

    let unsubscribers: { unlistenHandshake: () => void; unlistenDisconnect: () => void } | null = null;
    initHandshake().then(unsubs => { 
      if (active) unsubscribers = unsubs; 
      else {
        unsubs.unlistenHandshake();
        unsubs.unlistenDisconnect();
      }
    });

    return () => {
      active = false;
      if (unsubscribers) {
        unsubscribers.unlistenHandshake();
        unsubscribers.unlistenDisconnect();
      }
    };
  }, [addLog]);

  const safeSetTabs = useCallback((newTabs: FileTab[], newActiveTabId: number) => {
    if (newTabs.length === 0) {
      const fallback = { ...DEFAULT_TAB, id: Date.now() };
      setTabs([fallback]);
      setActiveTabId(fallback.id);
      saveTabs({ tabs: [fallback], activeTabId: fallback.id });
    } else {
      setTabs(newTabs);
      setActiveTabId(newActiveTabId);
      saveTabs({ tabs: newTabs, activeTabId: newActiveTabId });
    }
  }, []);

  const [favorites, setFavorites] = useState<FavoriteEntry[]>(() => loadFavorites());

  const addFavorite = useCallback((tab: FileTab) => {
    setFavorites(prev => {
      const already = prev.find(f => f.name === tab.name);
      if (already) {
        const next = prev.map(f => f.name === tab.name ? { ...f, content: tab.content } : f);
        saveFavorites(next);
        return next;
      }
      const next = [...prev, { id: `fav-${Date.now()}`, name: tab.name, content: tab.content, addedAt: Date.now() }];
      saveFavorites(next);
      return next;
    });
  }, []);

  const removeFavorite = useCallback((id: string) => {
    setFavorites(prev => {
      const next = prev.filter(f => f.id !== id);
      saveFavorites(next);
      return next;
    });
  }, []);

  const isTabFavorited = useCallback((tab: FileTab) => {
    return favorites.some(f => f.name === tab.name);
  }, [favorites]);

  const [scriptTree, setScriptTree] = useState<ScriptTreeNode[]>([]);
  const [activeFileStoreId, setActiveFileStoreId] = useState<string | null>(null);
  const [addModal, setAddModal] = useState<{ parentPath: string } | null>(null);

  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);

  useEffect(() => {
    initializeFileStore().then(() => {
      setScriptTree(fileStore.getScriptTree());
    });
    const unsub = subscribeToFileStore(() => {
      setScriptTree(fileStore.getScriptTree());
    });
    return unsub;
  }, []);

  useEffect(() => {
    const activeTab = tabs.find(t => t.id === activeTabId);
    if (activeTab) {
      const allFiles = fileStore.getAllFiles();
      const matchingFile = allFiles.find(f => f.name === activeTab.name);
      setActiveFileStoreId(matchingFile?.id ?? null);
    } else {
      setActiveFileStoreId(null);
    }
  }, [activeTabId, tabs]);

  const openTreeFile = useCallback((node: ScriptTreeNode) => {
    if (!node.fileId) return;
    const vf = fileStore.getFile(node.fileId);
    if (!vf) return;
    setActiveFileStoreId(node.fileId);

    setTabs(prevTabs => {
      const existing = prevTabs.find(tab => tab.name === vf.name);
      if (existing) {
        setActiveTabId(existing.id);
        saveTabs({ tabs: prevTabs, activeTabId: existing.id });
        return prevTabs;
      }

      if (
        prevTabs.length === 1 &&
        (prevTabs[0].name === 'Untitled' || prevTabs[0].name.startsWith('Untitled')) &&
        prevTabs[0].content === ''
      ) {
        const updated = [{ ...prevTabs[0], name: vf.name, content: vf.content }];
        setActiveTabId(updated[0].id);
        saveTabs({ tabs: updated, activeTabId: updated[0].id });
        return updated;
      }

      const newTab: FileTab = { id: Date.now(), name: vf.name, content: vf.content };
      const updated = [...prevTabs, newTab];
      setActiveTabId(newTab.id);
      saveTabs({ tabs: updated, activeTabId: newTab.id });
      return updated;
    });
  }, []);

  const deleteTreeNode = useCallback(async (node: ScriptTreeNode) => {
    try {
      if (node.isDir) {
        const allFiles = fileStore.getAllFiles();
        const rel = node.relativePath;
        const affected = allFiles.filter(f =>
          f.relativePath === rel || f.relativePath.startsWith(rel + '\\') || f.relativePath.startsWith(rel + '/')
        );
        await fileStore.deletePath(node.relativePath, true);
        setTabs(prev => {
          let next = [...prev];
          let newActive = activeTabId;
          for (const f of affected) {
            const hit = next.find(tab => tab.name === f.name);
            if (hit && next.length > 1) {
              const idx = next.findIndex(tab => tab.id === hit.id);
              next = next.filter(tab => tab.id !== hit.id);
              if (newActive === hit.id) newActive = next[Math.min(idx, next.length - 1)].id;
            }
          }
          const safeTabs = next.length > 0 ? next : [{ ...DEFAULT_TAB, id: Date.now() }];
          const safeActive = safeTabs.find(t => t.id === newActive) ? newActive : safeTabs[0].id;
          saveTabs({ tabs: safeTabs, activeTabId: safeActive });
          setActiveTabId(safeActive);
          return safeTabs;
        });
      } else if (node.fileId) {
        const vf = fileStore.getFile(node.fileId);
        await fileStore.deleteFile(node.fileId);
        if (vf) {
          setTabs(prev => {
            const hit = prev.find(tab => tab.name === vf.name);
            if (!hit) return prev;
            if (prev.length === 1) {
              const fallback = { ...DEFAULT_TAB, id: Date.now() };
              setActiveTabId(fallback.id);
              saveTabs({ tabs: [fallback], activeTabId: fallback.id });
              return [fallback];
            }
            const idx = prev.findIndex(tab => tab.id === hit.id);
            const next = prev.filter(tab => tab.id !== hit.id);
            const newActive = activeTabId === hit.id ? next[Math.min(idx, next.length - 1)].id : activeTabId;
            saveTabs({ tabs: next, activeTabId: newActive });
            setActiveTabId(newActive);
            return next;
          });
        }
        if (activeFileStoreId === node.fileId) setActiveFileStoreId(null);
      }
    } catch (err) {
      addLog('error', `Delete failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [activeTabId, activeFileStoreId]);

  const handleAddItem = useCallback(async (name: string, type: 'file' | 'folder', parentPath: string) => {
    setAddModal(null);
    try {
      if (type === 'file') {
        const vf = await fileStore.createFile(name, '', parentPath);
        setActiveFileStoreId(vf.id);
        setTabs(prevTabs => {
          if (
            prevTabs.length === 1 &&
            (prevTabs[0].name === 'Untitled' || prevTabs[0].name.startsWith('Untitled')) &&
            prevTabs[0].content === ''
          ) {
            const updated = [{ ...prevTabs[0], name: vf.name, content: vf.content }];
            setActiveTabId(updated[0].id);
            saveTabs({ tabs: updated, activeTabId: updated[0].id });
            return updated;
          }
          const newTab: FileTab = { id: Date.now(), name: vf.name, content: vf.content };
          const updated = [...prevTabs, newTab];
          setActiveTabId(newTab.id);
          saveTabs({ tabs: updated, activeTabId: newTab.id });
          return updated;
        });
      } else {
        await fileStore.createDirectory(name, parentPath);
      }
    } catch (err) {
      addLog('error', `Create failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, []);

  const handleTreeDragStart = useCallback((id: string) => {
    setDraggingNodeId(id);
  }, []);

  const handleTreeDragOver = useCallback((e: React.DragEvent, _id: string) => {
    e.preventDefault();
  }, []);

  const handleTreeDrop = useCallback(async (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    if (!draggingNodeId || draggingNodeId === targetId) { setDraggingNodeId(null); return; }

    const allNodes = flattenTree(fileStore.getScriptTree());
    const dragNode = allNodes.find(n => n.id === draggingNodeId);
    const targetNode = allNodes.find(n => n.id === targetId);
    if (!dragNode || !targetNode) { setDraggingNodeId(null); return; }

    const destPath = targetNode.isDir ? targetNode.relativePath : getParentPath(targetNode.relativePath);

    try {
      if (dragNode.isDir) {
        await fileStore.moveDirectory(dragNode.relativePath, destPath);
      } else if (dragNode.fileId) {
        await fileStore.moveFile(dragNode.fileId, destPath);
      }
    } catch (err) {
      addLog('error', `Move failed: ${err instanceof Error ? err.message : String(err)}`);
    }
    setDraggingNodeId(null);
  }, [draggingNodeId]);

  const handleAddToAutoExec = useCallback(async (tab: FileTab) => {
    if (!autoexecPath) return;
    try {
      const fileName = tab.name.endsWith('.lua') || tab.name.endsWith('.luau') || tab.name.endsWith('.txt')
        ? tab.name
        : tab.name + '.lua';
      await writeTextFile(`${autoexecPath}\\${fileName}`, tab.content);
      addLog('success', `Added "${fileName}" to auto-exec`);
      try {
        const { readDir } = await import('@tauri-apps/plugin-fs');
        const entries = await readDir(autoexecPath);
        const scripts: ScriptEntry[] = [];
        for (let i = 0; i < entries.length; i++) {
          const e = entries[i];
          if (e.name && (e.name.endsWith('.lua') || e.name.endsWith('.luau') || e.name.endsWith('.txt'))) {
            try { scripts.push({ id: Date.now() + i, name: e.name, content: await readTextFile(`${autoexecPath}\\${e.name}`) }); } catch {}
          }
        }
        setAutoExec(scripts);
      } catch {}
    } catch (err) {
      addLog('error', `Auto-exec failed: ${err instanceof Error ? err.message : String(err)}`);
    }
  }, [autoexecPath]);

  const [ctxTabId,        setCtxTabId]        = useState<number|null>(null);
  const [ctxPos,          setCtxPos]          = useState({ x: 0, y: 0 });
  const [ctxOpen,         setCtxOpen]         = useState(false);
  const [renamingTabId,   setRenamingTabId]   = useState<number|null>(null);
  const [renameValue,     setRenameValue]     = useState('');
  const [draggedTabId,    setDraggedTabId]    = useState<number|null>(null);
  const [dropTargetIndex, setDropTargetIndex] = useState<number|null>(null);
  const [hoveredTabId,    setHoveredTabId]    = useState<number|null>(null);
  const dragStartPos   = useRef({ x: 0, y: 0 });
  const renameInputRef = useRef<HTMLInputElement>(null);
  const tabsScrollRef  = useRef<HTMLDivElement>(null);

  const [consoleLogs, setConsoleLogs] = useState<{ id: string; level: string; message: string; timestamp: Date }[]>([]);
  const consoleRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const getFem = () => getConsoleLogs().filter((l: any) => l.source === 'femware');
    setConsoleLogs(getFem());
    return subscribeToConsoleLogs(() => setConsoleLogs(getFem()));
  }, []);

  useEffect(() => { if (consoleRef.current) consoleRef.current.scrollTop = consoleRef.current.scrollHeight; }, [consoleLogs]);

  useEffect(() => { if (renamingTabId !== null) { renameInputRef.current?.focus(); renameInputRef.current?.select(); } }, [renamingTabId]);

  const [sidebarWidth,  setSidebarWidth]  = useState(276);
  const sbResizing    = useRef(false);
  const sbResizeStart = useRef({ x: 0, w: 0 });

  const [consoleHeight, setConsoleHeight] = useState(115);
  const [consoleOpen,   setConsoleOpen]   = useState(true);
  const conResizing    = useRef(false);
  const conResizeStart = useRef({ y: 0, h: 0 });

  const [accordionOpen, setAccordionOpen] = useState<Record<string,boolean>>({
    'Local Files': true, 'Auto Execute': false, 'Fem Cloud': false,
  });
  const [autoExec, setAutoExec] = useState<ScriptEntry[]>([]);

  useEffect(() => {
    if (!autoexecPath) return;
    const loadAuto = async () => {
      try {
        const { readDir } = await import('@tauri-apps/plugin-fs');
        const entries = await readDir(autoexecPath);
        const scripts: ScriptEntry[] = [];
        for (let i = 0; i < entries.length; i++) {
          const e = entries[i];
          if (e.name && (e.name.endsWith('.lua') || e.name.endsWith('.luau') || e.name.endsWith('.txt'))) {
            try { scripts.push({ id: Date.now()+i, name: e.name, content: await readTextFile(`${autoexecPath}\\${e.name}`) }); } catch {}
          }
        }
        setAutoExec(scripts);
      } catch {}
    };
    loadAuto();
  }, [autoexecPath]);

  const activeTab = tabs.find(t => t.id === activeTabId) ?? tabs[0];

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      if (sbResizing.current)  setSidebarWidth( Math.max(160, Math.min(400, sbResizeStart.current.w + e.clientX - sbResizeStart.current.x)));
      if (conResizing.current) setConsoleHeight(Math.max(50,  Math.min(320, conResizeStart.current.h - (e.clientY - conResizeStart.current.y))));
    };
    const onUp = () => {
      if (sbResizing.current)  saveTabs({ sidebarWidth });
      if (conResizing.current) saveTabs({ consoleHeight });
      sbResizing.current = false; conResizing.current = false;
    };
    window.addEventListener('mousemove', onMove); window.addEventListener('mouseup', onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, [sidebarWidth, consoleHeight]);

  useEffect(() => {
    const el = tabsScrollRef.current; if (!el) return;
    const onWheel = (e: WheelEvent) => { e.preventDefault(); el.scrollLeft += e.deltaY; };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => {
      if (el && !(el as any).removeGeometryListener) {
        el.removeEventListener('wheel', onWheel);
      }
    };
  }, []);

  useEffect(() => {
    if (draggedTabId === null) return;
    const draggedIdx = tabs.findIndex(t => t.id === draggedTabId);

    const onMove = (e: MouseEvent) => {
      const el = tabsScrollRef.current; if (!el) return;
      const tabElements  = Array.from(el.children);
      const containerRect = el.getBoundingClientRect();

      if (e.clientX > containerRect.right) {
        if (dropTargetIndex !== tabs.length) setDropTargetIndex(tabs.length);
        return;
      }

      let newTarget: number | null = null;
      for (let idx = 0; idx < tabElements.length; idx++) {
        const r   = tabElements[idx].getBoundingClientRect();
        const mid = (r.left + r.right) / 2;
        if (e.clientX < mid) { newTarget = idx; break; }
        newTarget = idx + 1;
      }
      if (newTarget !== null) {
        newTarget = Math.max(0, Math.min(newTarget, tabs.length));
        if (newTarget !== dropTargetIndex) setDropTargetIndex(newTarget);
      }
    };

    const onUp = () => {
      if (draggedTabId !== null && dropTargetIndex !== null && draggedIdx !== -1) {
        let toIdx = dropTargetIndex;
        if (draggedIdx < toIdx) toIdx = toIdx - 1;
        if (toIdx < 0) toIdx = 0;
        if (toIdx >= tabs.length) toIdx = tabs.length - 1;
        if (draggedIdx !== toIdx) {
          const newTabs = [...tabs];
          const [moved] = newTabs.splice(draggedIdx, 1);
          newTabs.splice(toIdx, 0, moved);
          setTabs(newTabs);
          saveTabs({ tabs: newTabs, activeTabId });
        }
      }
      setDraggedTabId(null);
      setDropTargetIndex(null);
    };

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup',  onUp);
    return () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
  }, [draggedTabId, dropTargetIndex, tabs, activeTabId]);

  function updateContent(content: string) {
    const nt = tabs.map(t => t.id === activeTabId ? { ...t, content } : t);
    setTabs(nt); saveTabs({ tabs: nt, activeTabId });
    if (activeFileStoreId) {
      fileStore.updateFile(activeFileStoreId, content).catch(() => {});
    }
  }

  function addTab() {
    const id = Date.now();
    const nt = [...tabs, { id, name: `Untitled ${tabs.length}`, content: '' }];
    setTabs(nt); setActiveTabId(id); saveTabs({ tabs: nt, activeTabId: id });
    setActiveFileStoreId(null);
  }

  function closeTab(id: number) {
    if (tabs.length === 1) {
      const fallback: FileTab = { id: Date.now(), name: 'Untitled', content: '' };
      setTabs([fallback]); setActiveTabId(fallback.id);
      saveTabs({ tabs: [fallback], activeTabId: fallback.id });
      setActiveFileStoreId(null);
      return;
    }
    const idx = tabs.findIndex(t => t.id === id);
    const nt  = tabs.filter(t => t.id !== id);
    setTabs(nt);
    const newId = activeTabId === id ? nt[Math.min(idx, nt.length - 1)].id : activeTabId;
    setActiveTabId(newId); saveTabs({ tabs: nt, activeTabId: newId });
    if (activeFileStoreId) {
      const closedTab = tabs.find(t => t.id === id);
      if (closedTab && closedTab.name === fileStore.getFile(activeFileStoreId)?.name) {
        setActiveFileStoreId(null);
      }
    }
  }

  function startRename(tabId: number) {
    const t = tabs.find(t => t.id === tabId); if (!t) return;
    setCtxOpen(false); setRenameValue(t.name); setRenamingTabId(tabId);
  }
  function commitRename() {
    if (renamingTabId === null) return;
    const v = renameValue.trim();
    if (v) {
      const nt = tabs.map(t => t.id === renamingTabId ? { ...t, name: v } : t);
      setTabs(nt); saveTabs({ tabs: nt, activeTabId });
    }
    setRenamingTabId(null); setRenameValue('');
  }
  function cancelRename() { setRenamingTabId(null); setRenameValue(''); }

  async function handleAttach() {
    try {
      const robloxProcesses = await invoke<any[]>('get_roblox_processes');
      if (robloxProcesses.length === 0) {
        addLog('error', 'Failed to attach: Roblox process not found');
        return;
      }

      const currentAttachedCount = getAttachedProcesses().length;
      if (currentAttachedCount >= robloxProcesses.length && currentAttachedCount > 0) {
        addLog('info', 'Already attached to all instances');
        return;
      }

      if (currentAttachedCount === 0) {
        startAttaching();
      }

      addLog('status', 'Launching loader...');
      await invoke('start_madium_server');
      await invoke('handle_attach', {}); 
    } catch (err) {
      addLog('error', `Failed to attach: ${String(err)}`);
      if (getAttachedProcesses().length === 0) {
        setDetached();
      }
    }
  }

  async function handleOpenFile() {
    try {
      const sel = await open({ multiple: false, filters: [{ name: 'Scripts', extensions: ['lua','luau','txt'] }] });
      if (!sel || typeof sel !== 'string') return;
      const content = await readTextFile(sel);
      const name = sel.split(/[/\\]/).pop() || 'file.lua';
      setTabs(prevTabs => {
        const existing = prevTabs.find(tab => tab.name === name);
        if (existing) {
          setActiveTabId(existing.id);
          saveTabs({ tabs: prevTabs, activeTabId: existing.id });
          return prevTabs;
        }
        if (prevTabs.length === 1 && (prevTabs[0].name === 'Untitled' || prevTabs[0].name.startsWith('Untitled')) && prevTabs[0].content === '') {
          const updated = [{ ...prevTabs[0], name, content }];
          setActiveTabId(updated[0].id);
          saveTabs({ tabs: updated, activeTabId: updated[0].id });
          return updated;
        }
        const newTab: FileTab = { id: Date.now(), name, content };
        const updated = [...prevTabs, newTab];
        setActiveTabId(newTab.id);
        saveTabs({ tabs: updated, activeTabId: newTab.id });
        return updated;
      });
    } catch { addLog('error', 'Failed to open file'); }
  }

  async function handleSaveFile() {
    if (!activeTab) return;
    try {
      const p = await save({ defaultPath: activeTab.name, filters: [{ name: 'Lua', extensions: ['lua','luau'] }] });
      if (p) { await writeTextFile(p, activeTab.content); addLog('success', `Saved ${activeTab.name}`); }
    } catch { addLog('error', 'Failed to save file'); }
  }

  function consoleBadgeLabel() {
    return madiumConnected ? 'Connected' : 'Not Connected';
  }
  function tabWidth(name: string) { return Math.max(60, Math.min(250, name.length * 7 + 32)); }

  return (
    <div onClick={() => setCtxOpen(false)} style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 2, minHeight: 0, width: '100%' }}>

      <style>{`
        @keyframes knobPop {
          0%   { transform: scale(1); }
          35%  { transform: scale(0.68); }
          65%  { transform: scale(1.18); }
          100% { transform: scale(1); }
        }
        .fw-kw   { color: ${activeSyntaxTheme.kw}; }
        .fw-str  { color: ${activeSyntaxTheme.str}; }
        .fw-cmt  { color: ${activeSyntaxTheme.cmt}; }
        .fw-num  { color: ${activeSyntaxTheme.num}; }
        .fw-fn   { color: ${activeSyntaxTheme.fn}; }
        .fw-op   { color: ${activeSyntaxTheme.op}; }
        .fw-bi   { color: ${activeSyntaxTheme.bi}; }
        .fw-svc  { color: ${activeSyntaxTheme.svc}; }
        .fw-rblx { color: ${activeSyntaxTheme.rblx}; }
        .fw-type { color: ${activeSyntaxTheme.type}; }
      `}</style>

      {addModal && (
        <AddItemModal
          parentPath={addModal.parentPath}
          onConfirm={(name, type) => handleAddItem(name, type, addModal.parentPath)}
          onCancel={() => setAddModal(null)}
        />
      )}

      <div style={{ flex: 1, display: 'flex', gap: 2, minHeight: 0 }}>

        {sidebarOpen && (<>
          <div style={{ ...islandStyle, width: sidebarWidth, display: 'flex', flexDirection: 'column', overflow: 'hidden', flexShrink: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 14px 0', flexShrink: 0 }}>
              <span style={{ color: 'var(--fem-dark)', fontSize: 14, fontWeight: 500 }}>Script Explorer</span>
              <button onClick={() => setSidebarOpen(false)} style={{ width: 24, height: 24, border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}>
                <Icon src={sidebarIcon} size={18} active />
              </button>
            </div>

            <div style={{ padding: '8px 14px 0', flexShrink: 0 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '0 10px', height: 40, background: derived.islandBg, border: `1px solid ${derived.a20}`, boxShadow: 'var(--fem-inset-md)', borderRadius: 12 }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--fem-muted)" strokeWidth="2" style={{ flexShrink: 0 }}>
                  <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                </svg>
                <input placeholder="Search" style={{ flex: 1, background: 'none', border: 'none', outline: 'none', color: 'var(--fem-muted)', fontSize: 12, fontWeight: 500, fontFamily: 'inherit' }} />
              </div>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', padding: '8px 14px 14px' }}>

              <AccordionSection
                label="Local Files"
                icon={folderIcon}
                isOpen={accordionOpen['Local Files']}
                onToggle={o => { const s = { ...accordionOpen, 'Local Files': o }; setAccordionOpen(s); saveTabs({ accordionOpen: s }); }}
                headerExtra={
                  <button
                    title="New file or folder"
                    onClick={() => setAddModal({ parentPath: '' })}
                    style={{
                      width: 20, height: 20,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      background: 'none', border: 'none', cursor: 'pointer',
                      color: 'var(--fem-muted)', fontSize: 15, lineHeight: 1,
                      borderRadius: 4,
                      transition: 'color .15s',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.color = 'var(--fem-base)')}
                    onMouseLeave={e => (e.currentTarget.style.color = 'var(--fem-muted)')}
                  >+</button>
                }
              >
                {scriptTree.length === 0 && (
                  <p style={{ color: 'var(--fem-dim)', fontSize: 12, textAlign: 'center', margin: '8px 0' }}>No scripts yet</p>
                )}
                {scriptTree.map(node => (
                  <FolderTreeNode
                    key={node.id}
                    node={node}
                    depth={0}
                    activeFileId={activeFileStoreId}
                    onOpenFile={openTreeFile}
                    onDelete={deleteTreeNode}
                    onAddInside={parentPath => setAddModal({ parentPath })}
                    onDragStart={handleTreeDragStart}
                    onDragOver={handleTreeDragOver}
                    onDrop={handleTreeDrop}
                    draggingId={draggingNodeId}
                  />
                ))}
              </AccordionSection>

              <AccordionSection
                label="Auto Execute"
                icon={branchIcon}
                isOpen={accordionOpen['Auto Execute']}
                onToggle={o => { const s = { ...accordionOpen, 'Auto Execute': o }; setAccordionOpen(s); saveTabs({ accordionOpen: s }); }}
              >
                {autoExec.map(s => (
                  <ScriptRow key={s.id} name={s.name} selected={false}
                    onSelect={() => {
                      setTabs(prevTabs => {
                        const existing = prevTabs.find(tab => tab.name === s.name);
                        if (existing) { setActiveTabId(existing.id); saveTabs({ tabs: prevTabs, activeTabId: existing.id }); return prevTabs; }
                        if (prevTabs.length === 1 && (prevTabs[0].name === 'Untitled' || prevTabs[0].name.startsWith('Untitled')) && prevTabs[0].content === '') {
                          const updated = [{ ...prevTabs[0], name: s.name, content: s.content }];
                          setActiveTabId(updated[0].id); saveTabs({ tabs: updated, activeTabId: updated[0].id }); return updated;
                        }
                        const newTab: FileTab = { id: Date.now(), name: s.name, content: s.content };
                        const updated = [...prevTabs, newTab];
                        setActiveTabId(newTab.id); saveTabs({ tabs: updated, activeTabId: newTab.id }); return updated;
                      });
                    }}
                    onDelete={() => setAutoExec(p => p.filter(x => x.id !== s.id))} />
                ))}
                {autoExec.length === 0 && <p style={{ color: 'var(--fem-muted)', fontSize: 12, textAlign: 'center', margin: '8px 0', opacity: 0.7 }}>No auto-exec scripts</p>}
              </AccordionSection>

              <AccordionSection
                label="Fem Cloud"
                icon={cloudIcon}
                isOpen={accordionOpen['Fem Cloud']}
                onToggle={o => { const s = { ...accordionOpen, 'Fem Cloud': o }; setAccordionOpen(s); saveTabs({ accordionOpen: s }); }}
              >
                {favorites.length === 0 && (
                  <p style={{ color: 'var(--fem-muted)', fontSize: 12, textAlign: 'center', margin: '8px 0', opacity: 0.7 }}>No favorites yet</p>
                )}
                {favorites.map(fav => (
                  <ScriptRow
                    key={fav.id}
                    name={fav.name}
                    selected={false}
                    onSelect={() => {
                      setTabs(prevTabs => {
                        const existing = prevTabs.find(tab => tab.name === fav.name);
                        if (existing) { setActiveTabId(existing.id); saveTabs({ tabs: prevTabs, activeTabId: existing.id }); return prevTabs; }
                        if (prevTabs.length === 1 && (prevTabs[0].name === 'Untitled' || prevTabs[0].name.startsWith('Untitled')) && prevTabs[0].content === '') {
                          const updated = [{ ...prevTabs[0], name: fav.name, content: fav.content }];
                          setActiveTabId(updated[0].id); saveTabs({ tabs: updated, activeTabId: updated[0].id }); return updated;
                        }
                        const newTab: FileTab = { id: Date.now(), name: fav.name, content: fav.content };
                        const updated = [...prevTabs, newTab];
                        setActiveTabId(newTab.id);
                        saveTabs({ tabs: updated, activeTabId: newTab.id });
                        return updated;
                      });
                    }}
                    onDelete={() => removeFavorite(fav.id)}
                  />
                ))}
              </AccordionSection>
            </div>
          </div>

          <div
            style={{ width: 2, flexShrink: 0, cursor: 'col-resize', transition: 'background .15s' }}
            onMouseEnter={e => (e.currentTarget.style.background = derived.a40)}
            onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
            onMouseDown={e => { sbResizing.current = true; sbResizeStart.current = { x: e.clientX, w: sidebarWidth }; e.preventDefault(); }}
          />
        </>)}

        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0, gap: 0 }}>

          <div style={{ display: 'flex', alignItems: 'flex-end', height: 47, flexShrink: 0 }}>
            <div ref={tabsScrollRef} style={{ display: 'flex', alignItems: 'flex-end', flex: 1, height: '100%', overflowX: 'auto', overflowY: 'visible', scrollbarWidth: 'none' }}>
              {tabs.map((tab, i) => {
                const isActive   = tab.id === activeTabId;
                const isLast     = i === tabs.length - 1;
                const isRenaming = renamingTabId === tab.id;
                const isHovered  = hoveredTabId === tab.id;
                const tw         = tabWidth(tab.name);

                const resolvedBg = derived.islandBg;
                const resolvedShadow = isActive
                  ? `${derived.islandShadow}, inset 0 0 40px ${derived.a33}`
                  : isHovered
                  ? `inset 0 0 12px ${derived.a40}, ${derived.glowMd}`
                  : `inset 0 0 28px ${derived.a40}, ${derived.glowSm}`;

                return (
                  <div key={tab.id}
                    onClick={() => { if (!isRenaming && draggedTabId === null) { setActiveTabId(tab.id); saveTabs({ tabs, activeTabId: tab.id }); } }}
                    onMouseEnter={() => setHoveredTabId(tab.id)}
                    onMouseLeave={() => setHoveredTabId(null)}
                    onMouseDown={e => { if (e.button === 0) { setDraggedTabId(tab.id); dragStartPos.current = { x: e.clientX, y: e.clientY }; } }}
                    onContextMenu={e => { e.preventDefault(); setCtxTabId(tab.id); setCtxPos({ x: e.clientX, y: e.clientY }); setCtxOpen(true); }}
                    style={{ height: '100%', flexShrink: 0, position: 'relative', width: tw, opacity: draggedTabId === tab.id ? 0.5 : 1, userSelect: 'none', cursor: 'pointer', borderTopLeftRadius: i === 0 ? 6 : 0, borderTopRightRadius: isLast ? 6 : 0, overflow: 'hidden' }}
                  >
                    <div style={{
                      position: 'absolute', inset: 0,
                      background: resolvedBg,
                      boxShadow: resolvedShadow,
                      borderTopLeftRadius: i === 0 ? 6 : 0,
                      borderTopRightRadius: isLast ? 6 : 0,
                      transition: 'box-shadow 0.15s',
                    }} />

                    {dropTargetIndex === tabs.length && i === tabs.length - 1 && draggedTabId !== null && (
                      <div style={{ position: 'absolute', right: 0, top: 0, bottom: 0, width: 3, background: 'var(--fem-base)', zIndex: 10, borderRadius: 2 }} />
                    )}
                    {dropTargetIndex === i && draggedTabId !== null && draggedTabId !== tab.id && (
                      <div style={{ position: 'absolute', left: -1, top: 0, bottom: 0, width: 3, background: 'var(--fem-base)', zIndex: 10, borderRadius: 2 }} />
                    )}

                    <div style={{ position: 'relative', zIndex: 1, width: '100%', height: '100%', display: 'flex', alignItems: 'center', gap: 4, padding: '0 4px 0 10px' }}>
                      {isRenaming ? (
                        <input ref={renameInputRef} value={renameValue}
                          onChange={e => setRenameValue(e.target.value)}
                          onBlur={commitRename}
                          onKeyDown={e => { if (e.key === 'Enter') commitRename(); if (e.key === 'Escape') cancelRename(); }}
                          onClick={e => e.stopPropagation()}
                          style={{ flex: 1, minWidth: 40, background: 'transparent', border: 'none', borderBottom: '1px solid var(--fem-base)', outline: 'none', color: 'var(--fem-base)', fontSize: 12, fontWeight: 600, fontFamily: 'inherit', padding: '0 2px', caretColor: 'var(--fem-base)' }}
                        />
                      ) : (
                        <span style={{
                          fontSize: 12, fontWeight: 600,
                          color: isActive ? 'var(--fem-base)' : isHovered ? 'var(--fem-dark)' : 'var(--fem-muted)',
                          whiteSpace: 'nowrap',
                          transition: 'color 0.15s',
                        }}>
                          {tab.name}
                        </span>
                      )}
                      <button onClick={e => { e.stopPropagation(); closeTab(tab.id); }}
                        style={{ background: 'none', border: 'none', cursor: 'pointer', color: isActive ? 'var(--fem-base)' : 'var(--fem-muted)', width: 16, height: 16, fontSize: 14, lineHeight: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, opacity: 0.7, marginLeft: 2, transition: 'color 0.15s' }}>
                        ×
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
            <button onClick={addTab} style={{ width: 26, height: 26, flexShrink: 0, alignSelf: 'center', margin: '0 4px', borderRadius: 6, border: 'none', background: derived.islandBg, color: 'var(--fem-dark)', fontSize: 16, cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</button>
          </div>

          <div style={{
            ...islandStyle,
            flex: 1, display: 'flex', flexDirection: 'column',
            overflow: 'hidden', minHeight: 0, marginTop: 0,
            borderTopLeftRadius: 0, borderTopRightRadius: 6,
            borderBottomLeftRadius: 6, borderBottomRightRadius: 6,
          }}>
            <div style={{ flex: 1, overflow: 'hidden', minHeight: 0 }}>
              {loading ? (
                <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--fem-muted)', fontSize: 13, fontWeight: 500 }}>
                  Loading workspace...
                </div>
              ) : (
                <CodeEditor
                  value={activeTab?.content || ''}
                  onChange={updateContent}
                  fileId={String(activeTabId)}
                  fileName={activeTab?.name}
                  onExecute={async () => {
                    try {
                      await invoke('execute_madium', { 
                        script: activeTab?.content || '', 
                        pids: getSelectedPids()
                      });
                      addLog('success', `Executed ${activeTab?.name || 'Untitled Tab'}`);
                    } catch (err) { addLog('error', err instanceof Error ? err.message : 'Execute failed'); }
                  }}
                />
              )}
            </div>

            <div style={{ padding: '8px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0, gap: 6, borderTop: '1px solid var(--fem-a20)' }}>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                <ActionBtn label="Execute" onClick={async () => {
                  try {
                    await invoke('execute_madium', { 
                      script: activeTab?.content || '', 
                      pids: getSelectedPids()
                    });
                    addLog('success', `Executed ${activeTab?.name || 'Untitled Tab'}`);
                  } catch (err) { addLog('error', err instanceof Error ? err.message : 'Execute failed'); }
                }} />
                <ActionBtn label="Clear Text" onClick={() => updateContent('')} />
                <ActionBtn label="Open File" onClick={handleOpenFile} />
                <ActionBtn label="Save File" onClick={handleSaveFile} />
              </div>
              <ActionBtn label="Attach" onClick={handleAttach} />
            </div>
          </div>
        </div>
      </div>

      {consoleOpen && (
        <div style={{ height: 2, flexShrink: 0, cursor: 'row-resize', transition: 'background .15s' }}
          onMouseEnter={e => (e.currentTarget.style.background = derived.a40)}
          onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
          onMouseDown={e => { conResizing.current = true; conResizeStart.current = { y: e.clientY, h: consoleHeight }; e.preventDefault(); }}
        />
      )}

      <div style={{ ...islandStyle, height: consoleOpen ? consoleHeight : 30, display: 'flex', flexDirection: 'column', overflow: 'hidden', flexShrink: 0, transition: 'height 0.2s ease' }}>
        <div style={{ height: 30, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 12px', borderBottom: consoleOpen ? `1px solid var(--fem-a12)` : 'none', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
            <button onClick={() => setConsoleOpen(v => !v)} style={{ width: 20, height: 20, border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0, flexShrink: 0 }}>
              <Icon src={sidebarIcon} size={16} active />
            </button>
            <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--fem-muted)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Console</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button onClick={() => clearConsoleLogs()} style={{ fontSize: 10, background: 'none', border: 'none', color: 'var(--fem-dark)', cursor: 'pointer', padding: '2px 6px', fontFamily: 'inherit' }}>Clear</button>
            <span style={{ fontSize: 11, color: 'var(--fem-dark)', display: 'flex', alignItems: 'center', gap: 5 }}>
              <span style={{ width: 7, height: 7, borderRadius: '50%', display: 'inline-block', transition: 'background 0.3s, box-shadow 0.3s', background: madiumConnected ? 'var(--fem-base)' : derived.a20, boxShadow: madiumConnected ? `0 0 5px ${derived.a80}` : undefined }} />
              {consoleBadgeLabel()}
            </span>
          </div>
        </div>
        {consoleOpen && (
          <div ref={consoleRef} style={{ flex: 1, padding: '6px 14px', fontFamily: 'Courier New, monospace', fontSize: 12, lineHeight: '18px', overflowY: 'auto', color: 'var(--fem-dark)', userSelect: 'text' }}>
            {consoleLogs.length === 0
              ? <div style={{ color: 'var(--fem-muted)' }}>[FemWare] Ready</div>
              : consoleLogs.map(log => (
                <div key={log.id} style={{ color: log.level === 'error' ? '#ff6b6b' : log.level === 'warning' ? '#ffb74d' : log.level === 'success' ? '#81c784' : log.level === 'status' ? 'var(--fem-base)' : 'var(--fem-muted)' }}>
                  [{log.timestamp.toLocaleTimeString()}] {log.message}
                </div>
              ))
            }
          </div>
        )}
      </div>

      {ctxOpen && (
        <div
          onClick={e => e.stopPropagation()}
          className="fem-ctx-menu"
          style={{
            position: 'fixed',
            left: ctxPos.x,
            top: ctxPos.y,
            background: theme.bgColor || '#1a1a2e',
            border: `1px solid var(--fem-a30)`,
            borderRadius: 10,
            padding: 4,
            zIndex: 9999,
            minWidth: 160,
            boxShadow: `0 8px 32px rgba(0,0,0,0.8), 0 2px 8px rgba(0,0,0,0.6)`,
            opacity: 1,
          }}
        >
          {[
            { label: 'Rename tab',      action: () => { if (ctxTabId !== null) startRename(ctxTabId); },                 danger: false },
            null,
            { label: 'New tab',         action: () => { setCtxOpen(false); addTab(); },                                   danger: false },
            {
              label: (() => { const tab = tabs.find(t => t.id === ctxTabId); return tab && isTabFavorited(tab) ? '★ Unfavorite' : '☆ Favorite'; })(),
              action: () => {
                setCtxOpen(false);
                const tab = tabs.find(t => t.id === ctxTabId);
                if (!tab) return;
                if (isTabFavorited(tab)) {
                  const fav = favorites.find(f => f.name === tab.name);
                  if (fav) removeFavorite(fav.id);
                } else {
                  addFavorite(tab);
                }
              },
              danger: false,
            },
            {
              label: '+ Auto-Exec',
              action: () => {
                setCtxOpen(false);
                const tab = tabs.find(t => t.id === ctxTabId);
                if (tab) handleAddToAutoExec(tab);
              },
              danger: false,
            },
            null,
            { label: 'Close tab',       action: () => { setCtxOpen(false); if (ctxTabId != null) closeTab(ctxTabId); },  danger: true  },
          ].map((item, i) =>
            item === null
              ? <div key={i} style={{ height: 1, background: 'var(--fem-a20)', margin: '3px 6px' }} />
              : <div key={i} onClick={item.action}
                  style={{
                    padding: '8px 14px', fontSize: 12, fontWeight: 500,
                    color: item.danger ? '#e05080' : 'var(--fem-darker)',
                    borderRadius: 7, cursor: 'pointer',
                    transition: 'background .1s',
                  }}
                  onMouseEnter={e => (e.currentTarget.style.background = item.danger ? 'rgba(224,80,128,.15)' : derived.a20)}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >{item.label}</div>
          )}
        </div>
      )}
    </div>
  );
}

function flattenTree(nodes: ScriptTreeNode[]): ScriptTreeNode[] {
  const result: ScriptTreeNode[] = [];
  const walk = (ns: ScriptTreeNode[]) => { for (const n of ns) { result.push(n); if (n.children) walk(n.children); } };
  walk(nodes);
  return result;
}

function getParentPath(relativePath: string): string {
  const parts = relativePath.replace(/\\/g, '/').split('/');
  parts.pop();
  return parts.join('/');
}