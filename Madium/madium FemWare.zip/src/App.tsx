import { useState, useEffect } from 'react';
import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
import { invoke } from '@tauri-apps/api/core';
import { LoginPage } from './components/auth/LoginPage';
import { FemwareApp } from './components/femware/FemwareApp';
import { ThemeProvider, preloadTheme } from './context/themeContext';
import { loadClientSettings } from './stores/clientSettingsStore';
import { loadSettings } from './stores/settingsStore';
import { validateSession } from './stores/authStore';
import astolfoBg from './assets/astolfo.png?inline';
import './styles/globals.css';

export default function App() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [themeReady, setThemeReady] = useState(false);

  useEffect(() => {
    console.log('[App] Component mounted, starting init...');
    const init = async () => {
      try {
        console.log('[App] Preloading theme...');
        await preloadTheme();
        // Wait two frames so WebView fully paints images before showing UI
        await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
        setThemeReady(true);

        console.log('[App] Loading settings...');
        await Promise.all([loadClientSettings(), loadSettings()]);

        console.log('[App] Starting Madium WebSocket server...');
        await invoke('start_madium_server');

        console.log('[App] Setting window size...');
        const win = getCurrentWindow();
        await win.setSize(new LogicalSize(358, 420));
        await win.setResizable(false);
        await win.center();

        console.log('[App] Validating license...');
        validateSession()
          .then(valid => { if (valid) expandToDashboard(); else setAuthed(false); })
          .catch(() => setAuthed(false));
      } catch (err) {
        console.error('[App] Init error:', err);
        setThemeReady(true);
        setAuthed(true);
      }
    };
    init();
  }, []);

  const expandToDashboard = async () => {
    const win = getCurrentWindow();
    await win.setResizable(true);
    await win.setSize(new LogicalSize(1200, 700));
    await win.center();
    setAuthed(true);
  };

  if (!themeReady || authed === null) return null;
  if (!authed) return <LoginPage onLogin={expandToDashboard} />;

  return (
    <ThemeProvider astolfoAssetUrl={astolfoBg}>
      <FemwareApp />
    </ThemeProvider>
  );
}