import { useRef, useEffect, useCallback, useState } from 'react';
import Editor, { OnMount, OnChange, loader } from '@monaco-editor/react';
import type * as Monaco from 'monaco-editor';
import { registerLuauLanguage, syncMonacoTheme, LUAU_LANGUAGE_ID, type SyntaxColors } from './luauLanguage';
import { resolveSyntaxColors, DEFAULT_SYNTAX_THEME, DEFAULT_SYNTAX_MODE } from '../constants/syntaxThemes';
import { registerLuauCompletionProvider } from './luauCompletions';
import { registerLuauLspProviders } from './luauLsp';
import { registerGhostTextProvider } from './completions/ghostText';
import { loadUsageData } from './completions/usageTracker';
import { runDiagnostics } from './luauDiagnostics';
import { getSettings, subscribeToSettings, EditorSettings } from '../stores/settingsStore';
import { getQuickExecuteSettings, matchesKeybind } from '../stores/quickExecuteStore';
import { subscribeToNavigation } from '../stores/editorNavigationStore';
import { useFemTheme } from '../context/themeContext';

export interface EditorPosition {
  line: number;
  column: number;
}

export interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  onCursorChange?: (position: EditorPosition) => void;
  onExecute?: () => void;
  onSave?: () => void;
  readOnly?: boolean;
  fileId?: string;
  fileName?: string;
  language?: string;
}

let isLanguageRegistered = false;
let lspProviders: Monaco.IDisposable[] = [];
let lspProvidersEnabled = false;

// Pre-define the theme before any editor instance mounts so the first paint
// uses the correct colors instead of flashing grey VS Dark for one frame.
// We read the theme from the CSS variables that preloadTheme() already injected.
loader.init().then((monaco) => {
  const style = document.documentElement.style;
  const h = parseInt(style.getPropertyValue('--fem-h') || '315', 10);
  const s = parseInt((style.getPropertyValue('--fem-s') || '100%').replace('%', ''), 10);
  const l = parseInt((style.getPropertyValue('--fem-l') || '75%').replace('%', ''), 10);
  syncMonacoTheme(monaco, { hue: h, sat: s, lit: l }, {
    kw:   style.getPropertyValue('--fem-base').trim()   || '#f472b6',
    str:  style.getPropertyValue('--fem-base').trim()   || '#f472b6',
    cmt:  style.getPropertyValue('--fem-muted').trim()  || '#9ca3af',
    num:  style.getPropertyValue('--fem-base').trim()   || '#f472b6',
    fn:   style.getPropertyValue('--fem-dark').trim()   || '#e879f9',
    svc:  style.getPropertyValue('--fem-dark').trim()   || '#e879f9',
    rblx: style.getPropertyValue('--fem-darker').trim() || '#c026d3',
    type: style.getPropertyValue('--fem-base').trim()   || '#f472b6',
    // op and bi default to a desaturated/shifted version of the base accent for the pre-init pass.
    // These get replaced immediately once the real theme resolves on mount.
    op:   style.getPropertyValue('--fem-muted').trim()  || '#9ca3af',
    bi:   style.getPropertyValue('--fem-darker').trim() || '#c026d3',
  });
});

function syncLuauLspProviders(monaco: typeof Monaco, enabled: boolean): void {
  if (enabled === lspProvidersEnabled) return;
  if (enabled) {
    lspProviders = registerLuauLspProviders(monaco);
  } else {
    lspProviders.forEach((provider) => provider.dispose());
    lspProviders = [];
  }
  lspProvidersEnabled = enabled;
}

export function CodeEditor({
  value,
  onChange,
  onCursorChange,
  onExecute,
  onSave,
  readOnly = false,
  fileId,
  fileName,
  language = LUAU_LANGUAGE_ID,
}: CodeEditorProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const editorRef = useRef<Monaco.editor.IStandaloneCodeEditor | null>(null);
  const monacoRef = useRef<typeof Monaco | null>(null);
  // One Monaco model per fileId so each tab has its own isolated undo stack.
  const modelCacheRef = useRef<Map<string, Monaco.editor.ITextModel>>(new Map());
  const [editorSettings, setEditorSettings] = useState<EditorSettings>(getSettings().editor);
  const [isEditorMounted, setIsEditorMounted] = useState(false);
  const { derived, theme } = useFemTheme();
  const t = theme as any;

  const syntaxColors: SyntaxColors = resolveSyntaxColors(
    t.syntaxMode  ?? DEFAULT_SYNTAX_MODE,
    t.syntaxTheme ?? DEFAULT_SYNTAX_THEME,
    t.syntaxColors ?? null,
    t.syntaxAutoFlags ?? null,
    derived.h, derived.s, derived.l,
  );

  const syntaxColorsRef = useRef(syntaxColors);
  syntaxColorsRef.current = syntaxColors;
  const themeRef = useRef(t);
  themeRef.current = t;

  useEffect(() => {
    const unsubscribe = subscribeToSettings(() => {
      const newSettings = getSettings().editor;
      setEditorSettings(newSettings);
      if (monacoRef.current) {
        syncLuauLspProviders(monacoRef.current, newSettings.luauLsp);
      }
      if (editorRef.current) {
        editorRef.current.updateOptions({
          fontSize: newSettings.fontSize,
          tabSize: newSettings.tabSize,
          minimap: { enabled: newSettings.minimap },
          wordWrap: newSettings.wordWrap ? 'on' : 'off',
          lineNumbers: newSettings.lineNumbers ? 'on' : 'off',
          fontLigatures: newSettings.fontLigatures,
        });
      }
    });
    return unsubscribe;
  }, []);

  const handleEditorMount: OnMount = useCallback((editor, monaco) => {
    editorRef.current = editor;
    setIsEditorMounted(true);
    monacoRef.current = monaco;
    if (!isLanguageRegistered) {
      registerLuauLanguage(monaco);
      registerLuauCompletionProvider(monaco);
      registerGhostTextProvider(monaco);
      loadUsageData();
      isLanguageRegistered = true;
    }
    syncLuauLspProviders(monaco, getSettings().editor.luauLsp);
    syncMonacoTheme(monaco, themeRef.current, syntaxColorsRef.current);

    let lineDecorations: string[] = [];
    
    const updateLineHighlight = () => {
      if (!editor.getModel()) return;
      const selection = editor.getSelection();
      const hasSelection = selection ? !selection.isEmpty() : false;
      const position = editor.getPosition();
      
      if (!position || hasSelection) {
        lineDecorations = editor.deltaDecorations(lineDecorations, []);
        return;
      }
      
      lineDecorations = editor.deltaDecorations(lineDecorations, [{
        range: new monaco.Range(position.lineNumber, 1, position.lineNumber, 1),
        options: {
          isWholeLine: true,
          className: 'fw-current-line-highlight',
          marginClassName: 'fw-current-line-highlight-margin',
        },
      }]);
    };

    editor.onDidChangeCursorPosition(updateLineHighlight);
    editor.onDidChangeCursorSelection(updateLineHighlight);
    editor.onDidChangeModel(updateLineHighlight);
    editor.onDidFocusEditorText(updateLineHighlight);
    
    updateLineHighlight();

    editor.onDidChangeCursorPosition((e) => {
      if (onCursorChange) {
        onCursorChange({ line: e.position.lineNumber, column: e.position.column });
      }
    });

    editor.onKeyDown((e) => {
      const settings = getQuickExecuteSettings();
      const keyEvent = e.browserEvent;
      if (onExecute && matchesKeybind(keyEvent, settings.executeKeybind)) {
        e.preventDefault(); e.stopPropagation(); onExecute();
      }
      if (onSave && matchesKeybind(keyEvent, settings.saveKeybind)) {
        e.preventDefault(); e.stopPropagation(); onSave();
      }
    });

    const model = editor.getModel();
    if (language === LUAU_LANGUAGE_ID && model && fileId && fileName) {
      runDiagnostics(monaco, model, fileId, fileName);
    }

    // Patch ONLY the overviewRulerColor and minimap.color on Monaco occurrence
    // decorations. Monaco bakes these in from the theme at stamp time so they
    // don't update when setTheme is called later.
    // We use onDidChangeModelDecorations but guard heavily:
    //   1. Only run when occurrence deco COUNT changes (appear/disappear)
    //   2. Skip if already patched with the correct color
    //   3. isPatchingOccurrences flag stops our own deltaDecorations from
    //      re-triggering the listener
    let isPatchingOccurrences = false;
    let lastOccurrenceCount = 0;

    const getAccentColors = () => {
      const t = themeRef.current as any;
      const h = t.hue ?? 315;
      const s = t.sat ?? 100;
      const l = t.lit ?? 75;
      const l_ = l / 100;
      const a = (s * Math.min(l_, 1 - l_)) / 100;
      const f = (n: number) => {
        const k = (n + h / 30) % 12;
        const color = l_ - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
        return Math.round(255 * color).toString(16).padStart(2, '0');
      };
      const hex = '#' + f(0) + f(8) + f(4);
      return { a50: hex + '80', a65: hex + 'A6' };
    };

    editor.onDidChangeModelDecorations(() => {
      if (isPatchingOccurrences) return;
      const model = editor.getModel();
      if (!model) return;
      const occurrenceDecos = model.getAllDecorations().filter(d =>
        d.options.className === 'wordHighlight' ||
        d.options.className === 'wordHighlightStrong' ||
        d.options.className === 'wordHighlightText'
      );

      // Only do work when occurrences appear (count goes from 0 to N)
      const count = occurrenceDecos.length;
      if (count === 0) { lastOccurrenceCount = 0; return; }
      if (count === lastOccurrenceCount) return;
      lastOccurrenceCount = count;

      const { a50, a65 } = getAccentColors();

      // Skip if already correct
      if (occurrenceDecos.every(d => {
        const expected = d.options.className === 'wordHighlightStrong' ? a65 : a50;
        return d.options.overviewRuler?.color === expected;
      })) return;

      isPatchingOccurrences = true;
      editor.deltaDecorations(
        occurrenceDecos.map(d => d.id),
        occurrenceDecos.map(d => {
          const color = d.options.className === 'wordHighlightStrong' ? a65 : a50;
          return {
            range: d.range,
            options: {
              // Only override the minimap/ruler — leave everything else untouched
              className: d.options.className,
              stickiness: d.options.stickiness,
              overviewRulerColor: color,
              overviewRulerLane: monaco.editor.OverviewRulerLane.Center,
              minimap: {
                color,
                position: monaco.editor.MinimapPosition.Inline,
              },
            },
          };
        })
      );
      isPatchingOccurrences = false;
    });

    editor.focus();
  }, [onCursorChange, fileId, fileName, onExecute, onSave, language]);

  // Swap Monaco model when the active tab (fileId) changes.
  // Each fileId gets its own model with its own undo stack — switching tabs
  // no longer pushes onto the undo history of the tab you're switching to.
  useEffect(() => {
    const editor = editorRef.current;
    const monaco = monacoRef.current;
    if (!editor || !monaco || !fileId) return;

    const cache = modelCacheRef.current;
    let model = cache.get(fileId);

    if (!model || model.isDisposed()) {
      // First time seeing this fileId — create a fresh model with the current content
      const uri = monaco.Uri.parse(`femware://tab/${fileId}`);
      // Dispose any stale model at this URI
      const existing = monaco.editor.getModel(uri);
      if (existing) existing.dispose();
      model = monaco.editor.createModel(value, language, uri);
      cache.set(fileId, model);
    } else if (model.getValue() !== value) {
      // Model exists but content drifted (e.g. file was saved externally) — 
      // use pushEditOperations so even this sync doesn't pollute the undo stack
      model.pushEditOperations(
        [],
        [{ range: model.getFullModelRange(), text: value }],
        () => null
      );
    }

    editor.setModel(model);

    if (language === LUAU_LANGUAGE_ID && fileId && fileName) {
      runDiagnostics(monaco, model, fileId, fileName);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fileId, isEditorMounted]);

  const handleChange: OnChange = useCallback((newValue) => {
    if (newValue !== undefined) {
      onChange(newValue);
      if (language === LUAU_LANGUAGE_ID && monacoRef.current && editorRef.current && fileId && fileName) {
        const model = editorRef.current.getModel();
        if (model) {
          runDiagnostics(monacoRef.current, model, fileId, fileName);
        }
      }
    }
  }, [language, onChange, fileId, fileName]);

  const themeKey = JSON.stringify({ h: t.hue, s: t.sat, l: t.lit, bg: t.bgColor, syn: syntaxColors });

  useEffect(() => {
    loader.init().then((monaco) => {
      if (!isLanguageRegistered) {
        registerLuauLanguage(monaco);
        registerLuauCompletionProvider(monaco);
        registerGhostTextProvider(monaco);
        loadUsageData();
        isLanguageRegistered = true;
      }
      // NOTE: syncLuauLspProviders intentionally NOT called here.
      // This effect fires on every theme change and calling it each time
      // stacks duplicate hover/signature providers on top of each other.
      // LSP providers are registered once in handleEditorMount and managed
      // separately via the settings subscription.
      syncMonacoTheme(monaco, themeRef.current, syntaxColorsRef.current);
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [themeKey]);

  useEffect(() => {
    if (monacoRef.current) {
      syncMonacoTheme(monacoRef.current, themeRef.current, syntaxColorsRef.current);
    }
    // After a theme change, Monaco does not redraw already-rendered occurrence
    // decorations — they were stamped with the old theme CSS class at creation time.
    // The only reliable way to force them to redraw with the new theme colors is to
    // move the cursor away so Monaco clears the occurrences, then move it back so
    // it re-evaluates and redraws them fresh against the now-applied theme.
    if (editorRef.current) {
      const editor = editorRef.current;
      requestAnimationFrame(() => {
        const pos = editor.getPosition();
        if (!pos) return;
        // Step the cursor to a temporary position to clear current occurrences
        const tempLine = pos.lineNumber > 1 ? pos.lineNumber - 1 : pos.lineNumber + 1;
        const model = editor.getModel();
        const tempCol = model ? Math.min(pos.column, model.getLineMaxColumn(tempLine)) : 1;
        editor.setPosition({ lineNumber: tempLine, column: tempCol });
        // Step back to original position — Monaco re-evaluates occurrences here
        // with the new theme already applied, so they render with the correct color
        requestAnimationFrame(() => {
          editor.setPosition(pos);
        });
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [themeKey]);

  useEffect(() => {
    if (editorRef.current) {
      const position = editorRef.current.getPosition();
      if (position && onCursorChange) {
        onCursorChange({ line: position.lineNumber, column: position.column });
      }
    }
  }, [value, onCursorChange]);

  useEffect(() => {
    const targetId = fileId;
    if (!targetId) return;

    return subscribeToNavigation((request) => {
      if (request.fileId !== targetId || !editorRef.current) return;
      const editor = editorRef.current;
      editor.revealLineInCenter(request.line);
      editor.setPosition({ lineNumber: request.line, column: request.column });
      editor.focus();
    });
  }, [fileId]);

  useEffect(() => {
    const host = containerRef.current;
    if (!host) return;

    const layoutNow = () => {
      const editor = editorRef.current;
      if (!editor) return;
      const { clientWidth, clientHeight } = host;
      if (clientWidth <= 0 || clientHeight <= 0) return;
      editor.layout({ width: clientWidth, height: clientHeight });
    };

    layoutNow();
    const ro = new ResizeObserver(layoutNow);
    ro.observe(host);
    window.addEventListener('resize', layoutNow);

    return () => {
      ro.disconnect();
      window.removeEventListener('resize', layoutNow);
    };
  }, []);

  return (
    <div ref={containerRef} className="fw-monaco-shell" style={{ height: '100%', width: '100%', minHeight: 0, minWidth: 0 }}>
      <style>{`
        .fw-monaco-shell * { outline: none !important; }

        .fw-monaco-shell .monaco-editor .minimap {
          box-shadow: inset 1px 0 0 var(--fem-a20) !important;
        }

        .fw-monaco-shell .monaco-scrollable-element > .scrollbar,
        .fw-monaco-shell .monaco-scrollable-element > .scrollbar.vertical,
        .fw-monaco-shell .monaco-scrollable-element > .scrollbar.horizontal {
          background: transparent !important;
          background-color: transparent !important;
          box-shadow: none !important;
        }
        
        .fw-monaco-shell .monaco-scrollable-element > .shadow {
          display: none !important;
        }
        
        /* 💥 FIX: Restored the original, "pretty" scrollbar slider styles */
        .fw-monaco-shell .monaco-scrollable-element > .scrollbar > .slider {
          border-radius: 4px !important;
          background: var(--fem-a40) !important;
          box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1) !important;
          transition: background 0.15s !important;
        }
        .fw-monaco-shell .monaco-scrollable-element > .scrollbar > .slider-background {
          background: transparent !important;
        }
        .fw-monaco-shell .monaco-scrollable-element > .scrollbar > .slider:hover {
          background: var(--fem-a65) !important;
        }
        .fw-monaco-shell .monaco-scrollable-element > .scrollbar > .slider.active {
          background: var(--fem-base) !important;
        }

        .fw-monaco-shell .fw-current-line-highlight {
          width: 20000px !important;
          background: var(--fem-a08) !important;
          box-shadow: inset 0 1px 0 0 var(--fem-a20), inset 0 -1px 0 0 var(--fem-a20) !important;
          border: none !important;
        }
        
        .fw-monaco-shell .fw-current-line-highlight-margin {
          background: var(--fem-a08) !important;
          box-shadow: inset 0 1px 0 0 var(--fem-a20), inset 0 -1px 0 0 var(--fem-a20) !important;
          border: none !important;
        }

        /* ── Force all Monaco popups to VS Dark — no fem theme bleed ─────── */

        /* Suggest / autocomplete dropdown */
        .fw-monaco-shell .monaco-editor .suggest-widget,
        .fw-monaco-shell .monaco-editor .suggest-widget .monaco-list {
          background: #252526 !important;
          border-color: #454545 !important;
          color: #D4D4D4 !important;
        }
        .fw-monaco-shell .monaco-editor .suggest-widget .monaco-list .monaco-list-row.focused {
          background: #04395E !important;
          color: #FFFFFF !important;
        }
        .fw-monaco-shell .monaco-editor .suggest-widget .details,
        .fw-monaco-shell .monaco-editor .suggest-widget .details > .monaco-scrollable-element {
          background: #1e1e1e !important;
          border-color: #454545 !important;
        }

        /* Hover info widget */
        .fw-monaco-shell .monaco-editor .monaco-hover,
        .fw-monaco-shell .monaco-editor .monaco-hover .hover-contents {
          background: #252526 !important;
          border-color: #454545 !important;
          color: #D4D4D4 !important;
        }
        .fw-monaco-shell .monaco-editor .monaco-hover hr {
          border-color: #454545 !important;
        }

        /* Parameter hints */
        .fw-monaco-shell .monaco-editor .parameter-hints-widget {
          background: #252526 !important;
          border-color: #454545 !important;
          color: #D4D4D4 !important;
        }
        .fw-monaco-shell .monaco-editor .parameter-hints-widget .signature {
          background: #252526 !important;
        }
        .fw-monaco-shell .monaco-editor .parameter-hints-widget .documentation {
          background: #1e1e1e !important;
        }

        /* Find / Replace widget */
        .fw-monaco-shell .monaco-editor .find-widget {
          background: #252526 !important;
          border-color: #454545 !important;
          color: #CCCCCC !important;
          box-shadow: 0 2px 8px rgba(0,0,0,0.5) !important;
        }
        .fw-monaco-shell .monaco-editor .find-widget .monaco-inputbox {
          background: #3C3C3C !important;
          color: #CCCCCC !important;
        }
        .fw-monaco-shell .monaco-editor .find-widget .monaco-inputbox input {
          background: #3C3C3C !important;
          color: #CCCCCC !important;
        }
        .fw-monaco-shell .monaco-editor .find-widget .button:not(.disabled):hover {
          background: #3C3C3C !important;
        }

        /* Context menu — renders outside editor root so needs unscoped selectors */
        .monaco-menu .monaco-action-bar.vertical .action-item .action-menu-item,
        .monaco-menu .monaco-action-bar.vertical {
          background: #252526 !important;
          color: #CCCCCC !important;
        }
        .monaco-menu .monaco-action-bar.vertical .action-item .action-menu-item:hover,
        .monaco-menu .monaco-action-bar.vertical .action-item.focused .action-menu-item {
          background: #04395E !important;
          color: #FFFFFF !important;
        }
        .monaco-menu-container {
          background: #252526 !important;
          border-color: #454545 !important;
          box-shadow: 0 2px 8px rgba(0,0,0,0.5) !important;
        }

        /* Inline ghost / prediction text */
        .fw-monaco-shell .monaco-editor .ghost-text-decoration {
          opacity: 1 !important;
          color: #5A5A5A !important;
        }
        .fw-monaco-shell .monaco-editor .ghost-text-decoration-preview {
          color: #5A5A5A !important;
        }

        /* Rename / quick-fix input box */
        .fw-monaco-shell .monaco-editor .rename-box {
          background: #252526 !important;
          border-color: #454545 !important;
          color: #CCCCCC !important;
        }
      `}</style>
      <Editor
        height="100%"
        language={language}
        onChange={handleChange}
        onMount={handleEditorMount}
        theme="vs-dark"
        options={{
          accessibilitySupport: 'off',
          autoDetectHighContrast: false,
          fontSize: editorSettings.fontSize,
          fontFamily: "'JetBrains Mono', 'Fira Code', 'Cascadia Code', Consolas, monospace",
          fontLigatures: editorSettings.fontLigatures,
          lineHeight: 20,
          tabSize: editorSettings.tabSize,
          insertSpaces: true,
          minimap: {
            enabled: editorSettings.minimap,
            side: 'right',
            size: 'proportional',
            showSlider: 'mouseover',
            renderCharacters: false,
            maxColumn: 80,
          },
          scrollBeyondLastLine: false,
          wordWrap: editorSettings.wordWrap ? 'on' : 'off',
          lineNumbers: editorSettings.lineNumbers ? 'on' : 'off',
          renderLineHighlight: 'none', 
          cursorBlinking: 'smooth',
          cursorSmoothCaretAnimation: 'on',
          smoothScrolling: true,
          padding: { top: 10, bottom: 10 },
          readOnly,
          automaticLayout: true,
          suggestOnTriggerCharacters: true,
          quickSuggestions: true,
          parameterHints: { enabled: true },
          suggest: {
            showKeywords: true, showSnippets: true, showFunctions: true,
            showVariables: true, showClasses: true, showModules: true,
            showProperties: true, showMethods: true, showConstants: true,
            snippetsPreventQuickSuggestions: false, filterGraceful: false,
          },
          acceptSuggestionOnEnter: 'smart',
          acceptSuggestionOnCommitCharacter: false,
          bracketPairColorization: { enabled: true },
          autoClosingBrackets: 'always',
          autoClosingQuotes: 'always',
          autoIndent: 'full',
          formatOnPaste: true,
          formatOnType: true,
          folding: true,
          foldingStrategy: 'indentation',
          showFoldingControls: 'mouseover',
          matchBrackets: 'always',
          occurrencesHighlight: 'singleFile',
          renderWhitespace: 'selection',
          guides: { indentation: true, bracketPairs: true },
        }}
      />
    </div>
  );
}