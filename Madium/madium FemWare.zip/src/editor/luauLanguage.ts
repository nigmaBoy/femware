import type * as Monaco from 'monaco-editor';

export const LUAU_LANGUAGE_ID = 'luau';

export const luauTokensProvider: Monaco.languages.IMonarchLanguage = {
  defaultToken: '',
  tokenPostfix: '.luau',

  keywords: [
    'and', 'break', 'do', 'else', 'elseif', 'end', 'false', 'for', 'function',
    'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', 'return', 'then',
    'true', 'until', 'while', 'continue', 'export', 'type', 'typeof',
  ],

  builtinTypes: [
    'string', 'number', 'boolean', 'table', 'function', 'thread', 'userdata',
    'nil', 'any', 'never', 'unknown',
  ],

  robloxTypes: [
    'Instance', 'Player', 'Part', 'Model', 'Humanoid', 'Character', 'Tool',
    'Script', 'LocalScript', 'ModuleScript', 'RemoteEvent', 'RemoteFunction',
    'BindableEvent', 'BindableFunction', 'Vector3', 'Vector2', 'CFrame',
    'Color3', 'BrickColor', 'UDim', 'UDim2', 'Rect', 'Region3', 'Ray',
    'TweenInfo', 'NumberSequence', 'ColorSequence', 'NumberRange',
    'Faces', 'Axes', 'RaycastParams', 'OverlapParams', 'RaycastResult',
    'Enum', 'EnumItem', 'RBXScriptSignal', 'RBXScriptConnection',
  ],

  robloxGlobals: [
    'game', 'workspace', 'script', 'plugin', 'shared', 'Enum',
  ],

  robloxServices: [
    'Players', 'Workspace', 'ReplicatedStorage', 'ReplicatedFirst',
    'ServerStorage', 'ServerScriptService', 'StarterGui', 'StarterPack',
    'StarterPlayer', 'StarterPlayerScripts', 'StarterCharacterScripts',
    'Lighting', 'SoundService', 'TweenService', 'RunService', 'UserInputService',
    'ContextActionService', 'HttpService', 'MarketplaceService', 'DataStoreService',
    'MessagingService', 'TeleportService', 'TextService', 'PathfindingService',
    'PhysicsService', 'CollectionService', 'Debris', 'Chat', 'Teams',
    'BadgeService', 'InsertService', 'GamePassService', 'AssetService',
    'PolicyService', 'LocalizationService', 'MemoryStoreService',
  ],

  builtinFunctions: [
    'assert', 'collectgarbage', 'error', 'getfenv', 'getmetatable', 'ipairs',
    'loadstring', 'newproxy', 'next', 'pairs', 'pcall', 'print', 'rawequal',
    'rawget', 'rawset', 'require', 'select', 'setfenv', 'setmetatable',
    'tonumber', 'tostring', 'type', 'typeof', 'unpack', 'xpcall', 'warn',
  ],

  executorGlobals: [
    'identifyexecutor',
    'Drawing', 'debug', 'cloneref', 'compareinstances',
    'WebSocket', 'Websocket', 'websocket', 'raknet',
  ],

  executorEnvironment: [
    'getgenv', 'getrenv', 'getsenv',
    'getgc', 'filtergc', 'getreg', 'getinstances', 'getnilinstances', 'getscripts', 'getloadedmodules',
    'getrunningscripts', 'getcallingscript', 'getscriptclosure', 'getscripthash',
    'getscriptbytecode', 'getthreadidentity', 'setthreadidentity',
  ],

  executorHooking: [
    'hookfunction', 'hookmetamethod', 'restorefunction',
    'newcclosure', 'iscclosure', 'islclosure', 'isexecutorclosure',
    'checkcaller', 'clonefunction', 'getfunctionhash', 'getrawmetatable', 'setrawmetatable',
    'getnamecallmethod', 'gethiddenproperty',
    'sethiddenproperty', 'setreadonly', 'isreadonly', 'isscriptable', 'setscriptable',
  ],

  executorSecurity: [
    'getconstant', 'setconstant',
    'getconstants', 'getupvalue', 'setupvalue', 'getupvalues', 'getproto',
    'getprotos', 'getstack', 'setstack', 'getconnections',
    'firesignal', 'replicatesignal',
  ],

  executorFilesystem: [
    'readfile', 'writefile', 'appendfile', 'loadfile',
    'isfile', 'isfolder', 'makefolder', 'delfolder', 'delfile', 'listfiles',
    'getcustomasset',
  ],

  executorFiring: [
    'fireclickdetector', 'fireproximityprompt', 'firetouchinterest',
    'getcallbackvalue',
  ],

  executorMisc: [
    'request',
    'gethui', 'identifyexecutor',
    'lz4compress', 'lz4decompress', 'base64encode', 'base64decode',
    'cloneref', 'compareinstances', 'loadstring',
    'cleardrawcache', 'getrenderproperty', 'setrenderproperty', 'isrenderobj',
  ],

  taskFunctions: [
    'spawn', 'defer', 'delay', 'wait', 'cancel', 'synchronize', 'desynchronize',
  ],

  mathFunctions: [
    'abs', 'acos', 'asin', 'atan', 'atan2', 'ceil', 'clamp', 'cos', 'cosh',
    'deg', 'exp', 'floor', 'fmod', 'frexp', 'huge', 'ldexp', 'log', 'log10',
    'max', 'min', 'modf', 'noise', 'pi', 'pow', 'rad', 'random', 'randomseed',
    'round', 'sign', 'sin', 'sinh', 'sqrt', 'tan', 'tanh',
  ],

  stringFunctions: [
    'byte', 'char', 'dump', 'find', 'format', 'gmatch', 'gsub', 'len', 'lower',
    'match', 'pack', 'packsize', 'rep', 'reverse', 'split', 'sub', 'unpack', 'upper',
  ],

  tableFunctions: [
    'clear', 'clone', 'concat', 'create', 'find', 'foreach', 'foreachi',
    'freeze', 'getn', 'insert', 'isfrozen', 'maxn', 'move', 'pack', 'remove',
    'sort', 'unpack',
  ],

  operators: [
    '=', '>', '<', '!', '~', '?', ':', '==', '<=', '>=', '~=',
    'and', 'or', 'not', '+', '-', '*', '/', '%', '^', '#', '..',
    '+=', '-=', '*=', '/=', '%=', '^=', '..=',
  ],

  symbols: /[=><!~?:&|+\-*\/\^%#]+/,

  escapes: /\\(?:[abfnrtv\\"']|x[0-9A-Fa-f]{1,4}|u\{[0-9A-Fa-f]+\}|[0-9]{1,3})/,

  tokenizer: {
    root: [
      [/--\[(=*)\[/, 'comment', '@comment.$1'],
      [/--.*$/, 'comment'],

      [/\[(=*)\[/, 'string', '@string.$1'],

      [/"([^"\\]|\\.)*$/, 'string.invalid'],
      [/'([^'\\]|\\.)*$/, 'string.invalid'],
      [/"/, 'string', '@string_double'],
      [/'/, 'string', '@string_single'],

      [/\d*\.\d+([eE][\-+]?\d+)?/, 'number.float'],
      [/0[xX][0-9a-fA-F]+/, 'number.hex'],
      [/0[bB][01]+/, 'number.binary'],
      [/\d+/, 'number'],

      [/[a-zA-Z_]\w*/, {
        cases: {
          '@keywords': 'keyword',
          '@builtinTypes': 'type',
          '@robloxTypes': 'type.roblox',
          '@robloxGlobals': 'variable.roblox',
          '@robloxServices': 'variable.service',
          '@builtinFunctions': 'support.function.builtin',
          '@executorGlobals': 'support.function.builtin',
          '@executorEnvironment': 'support.function.builtin',
          '@executorHooking': 'support.function.builtin',
          '@executorSecurity': 'support.function.builtin',
          '@executorFilesystem': 'support.function.builtin',
          '@executorFiring': 'support.function.builtin',
          '@executorMisc': 'support.function.builtin',
          'self': 'variable.language',
          '@default': 'identifier',
        },
      }],

      [/[{}()\[\]]/, '@brackets'],
      [/@symbols/, {
        cases: {
          '@operators': 'operator',
          '@default': '',
        },
      }],

      [/[;,.]/, 'delimiter'],
    ],

    comment: [
      [/[^\]]+/, 'comment'],
      [/\](=*)\]/, {
        cases: {
          '$1==$S2': { token: 'comment', next: '@pop' },
          '@default': 'comment',
        },
      }],
      [/./, 'comment'],
    ],

    string: [
      [/[^\]]+/, 'string'],
      [/\](=*)\]/, {
        cases: {
          '$1==$S2': { token: 'string', next: '@pop' },
          '@default': 'string',
        },
      }],
      [/./, 'string'],
    ],

    string_double: [
      [/[^\\"]+/, 'string'],
      [/@escapes/, 'string.escape'],
      [/\\./, 'string.escape.invalid'],
      [/"/, 'string', '@pop'],
    ],

    string_single: [
      [/[^\\']+/, 'string'],
      [/@escapes/, 'string.escape'],
      [/\\./, 'string.escape.invalid'],
      [/'/, 'string', '@pop'],
    ],
  },
};

export function registerLuauLanguage(monaco: typeof Monaco): void {
  monaco.languages.register({ id: LUAU_LANGUAGE_ID });
  monaco.languages.setMonarchTokensProvider(LUAU_LANGUAGE_ID, luauTokensProvider);

  monaco.languages.setLanguageConfiguration(LUAU_LANGUAGE_ID, {
    comments: {
      lineComment: '--',
      blockComment: ['--[[', ']]'],
    },
    brackets: [
      ['{', '}'],
      ['[', ']'],
      ['(', ')'],
    ],
    autoClosingPairs: [
      { open: '{', close: '}' },
      { open: '[', close: ']' },
      { open: '(', close: ')' },
      { open: '"', close: '"', notIn: ['string'] },
      { open: "'", close: "'", notIn: ['string'] },
      { open: '[[', close: ']]' },
    ],
    surroundingPairs: [
      { open: '{', close: '}' },
      { open: '[', close: ']' },
      { open: '(', close: ')' },
      { open: '"', close: '"' },
      { open: "'", close: "'" },
    ],
    folding: {
      markers: {
        start: /^\s*--\s*#?region\b/,
        end: /^\s*--\s*#?endregion\b/,
      },
    },
    indentationRules: {
      increaseIndentPattern: /^\s*(else|elseif|for|function|if|repeat|while|do|then)\b.*$/,
      decreaseIndentPattern: /^\s*(end|else|elseif|until)\b.*$/,
    },
    wordPattern: /(-?\d*\.\d\w*)|([^\`\~\!\@\#\%\^\&\*\(\)\-\=\+\[\{\]\}\\\|\;\:\'\"\,\.\<\>\/\?\s]+)/g,
  });
}

function safeHslToHex(h: number, s: number, l: number): string {
  const l_ = l / 100;
  const a = (s * Math.min(l_, 1 - l_)) / 100;
  const f = (n: number) => {
    const k = (n + h / 30) % 12;
    const color = l_ - a * Math.max(Math.min(k - 3, 9 - k, 1), -1);
    return Math.round(255 * color).toString(16).padStart(2, '0');
  };
  return `#${f(0)}${f(8)}${f(4)}`;
}

function safeCssToHex(cssColor?: string): string {
  if (!cssColor) return 'D4D4D4';
  if (cssColor.startsWith('#')) return cssColor.slice(1);
  // hsl() with no spaces e.g. hsl(315,100%,75%)
  const matchTight = cssColor.match(/hsl\((-?\d+(?:\.\d+)?),\s*(-?\d+(?:\.\d+)?)%,\s*(-?\d+(?:\.\d+)?)%\)/);
  if (matchTight) {
    const h = parseFloat(matchTight[1]);
    const s = parseFloat(matchTight[2]);
    const l = parseFloat(matchTight[3]);
    return safeHslToHex(h, s, l).slice(1);
  }
  return 'D4D4D4';
}

// SyntaxColors now includes op (operators) and bi (executor/builtin functions)
export interface SyntaxColors {
  kw:   string;
  str:  string;
  cmt:  string;
  num:  string;
  fn:   string;
  svc:  string;
  rblx: string;
  type: string;
  op:   string;
  bi:   string;
}

let _themeGen = 0;

export function syncMonacoTheme(
  monaco: typeof Monaco, 
  theme: any,
  syn: SyntaxColors
): void {
  // Use the raw numbers from the theme object to prevent crashes.
  const accent = safeHslToHex(theme.hue ?? 315, theme.sat ?? 100, theme.lit ?? 75);
  const a12 = accent + '1F';
  const a15 = accent + '26';
  const a20 = accent + '33';
  const a30 = accent + '4C';
  const a40 = accent + '66';
  const a50 = accent + '80';
  const a65 = accent + 'A6';
  const a80 = accent + 'CC';

  let bg = (theme.bgColor && theme.bgColor.startsWith('#')) ? theme.bgColor : '#1e1e1e';
  if (bg.length === 4) bg = '#' + bg[1]+bg[1]+bg[2]+bg[2]+bg[3]+bg[3];
  const bgTransparent = bg.substring(0, 7) + '00';

  const themeName = `synapsez-dark-${++_themeGen}`;

  monaco.editor.defineTheme(themeName, {
    base: 'vs-dark',
    inherit: false,
    rules: [
      // Keywords: local, if, then, end, function, return, etc.
      { token: 'keyword',                    foreground: safeCssToHex(syn.kw) },
      // Strings
      { token: 'string',                     foreground: safeCssToHex(syn.str) },
      { token: 'string.escape',              foreground: safeCssToHex(syn.str) },
      { token: 'string.invalid',             foreground: safeCssToHex(syn.str) },
      // Comments
      { token: 'comment',                    foreground: safeCssToHex(syn.cmt), fontStyle: 'italic' },
      // Numbers (all variants)
      { token: 'number',                     foreground: safeCssToHex(syn.num) },
      { token: 'number.float',               foreground: safeCssToHex(syn.num) },
      { token: 'number.hex',                 foreground: safeCssToHex(syn.num) },
      { token: 'number.binary',              foreground: safeCssToHex(syn.num) },
      // Built-in functions: all executor/builtin groups now map to bi
      { token: 'support.function.builtin',   foreground: safeCssToHex(syn.bi) },
      // Regular named functions (called via identifier + parens, inferred by LSP)
      { token: 'support.function',           foreground: safeCssToHex(syn.fn) },
      { token: 'function.executor',          foreground: safeCssToHex(syn.bi) },
      // Types
      { token: 'type',                       foreground: safeCssToHex(syn.type) },
      { token: 'type.roblox',               foreground: safeCssToHex(syn.type) },
      // Roblox globals: game, workspace, script
      { token: 'variable.roblox',            foreground: safeCssToHex(syn.rblx) },
      // Roblox services: Players, ReplicatedStorage, etc.
      { token: 'variable.service',           foreground: safeCssToHex(syn.svc) },
      // General identifiers (variable names, function names in calls, etc.)
      { token: 'identifier',                 foreground: safeCssToHex(syn.rblx) },
      { token: 'variable.language',          foreground: safeCssToHex(syn.rblx) },
      // Operators: = + - * / % ^ # .. ~ . , ; : etc.
      { token: 'operator',                   foreground: safeCssToHex(syn.op) },
      { token: 'delimiter',                  foreground: safeCssToHex(syn.op) },
      // Default fallback
      { token: '',                           foreground: 'D4D4D4' },
    ],
    colors: {
      'editor.foreground': '#E2E8F0',
      'editor.background': bgTransparent,
      'editorGutter.background': bgTransparent,
      'minimap.background': bgTransparent,

      'editor.lineHighlightBorder': '#00000000',
      'editor.selectionHighlightBorder': '#00000000',
      'editor.wordHighlightBorder': '#00000000',
      'editor.wordHighlightStrongBorder': '#00000000',
      'editor.findMatchBorder': '#00000000',
      'editor.findMatchHighlightBorder': '#00000000',
      'editorBracketMatch.border': accent,

      'editor.selectionBackground': a30,
      'editor.selectionHighlightBackground': a15,
      'editor.wordHighlightBackground': a15,
      'editor.wordHighlightStrongBackground': a20,
      'editor.findMatchBackground': a40,
      'editor.findMatchHighlightBackground': a20,
      'editor.hoverHighlightBackground': a20,
      'editorBracketMatch.background': a12,
      'editorBracketHighlight.foreground1': accent,
      'editorBracketHighlight.foreground2': a65,
      'editorBracketHighlight.foreground3': a50,
      'editorBracketHighlight.foreground4': a40,
      'editorBracketHighlight.foreground5': a30,
      'editorBracketHighlight.foreground6': a20,
      'editorBracketHighlight.unexpectedBracket.foreground': 'D4D4D4',

      'minimap.selectionHighlight': a50,
      'minimap.findMatchHighlight': a50,
      'minimap.selectionOccurrenceHighlight': a50,
      'minimap.wordHighlight': a50,
      'minimap.wordHighlightStrong': a65,
      
      'minimapSlider.background': a20,
      'minimapSlider.hoverBackground': a40,
      'minimapSlider.activeBackground': a50,

      'editorOverviewRuler.border': '#00000000',
      'editorOverviewRuler.selectionHighlightForeground': a50,
      'editorOverviewRuler.wordHighlightForeground': a50,
      'editorOverviewRuler.wordHighlightStrongForeground': a65,
      'editorOverviewRuler.findMatchForeground': a65,
      'editorOverviewRuler.bracketMatchForeground': a65,

      'scrollbar.shadow': '#00000000',
      'scrollbarSlider.background': a40,
      'scrollbarSlider.hoverBackground': a65,
      'scrollbarSlider.activeBackground': a80,

      'editorCursor.foreground': accent,
      'editorLineNumber.foreground': a40,
      'editorLineNumber.activeForeground': accent,

      // ── Suggestion / autocomplete popup ──────────────────────────────────
      'editorSuggestWidget.background':               '#252526',
      'editorSuggestWidget.border':                   '#454545',
      'editorSuggestWidget.foreground':               '#D4D4D4',
      'editorSuggestWidget.selectedBackground':       '#04395E',
      'editorSuggestWidget.selectedForeground':       '#FFFFFF',
      'editorSuggestWidget.highlightForeground':      '#0097FB',
      'editorSuggestWidget.focusHighlightForeground': '#0097FB',

      // ── Hover info popup ──────────────────────────────────────────────────
      'editorHoverWidget.background':                 '#252526',
      'editorHoverWidget.border':                     '#454545',
      'editorHoverWidget.foreground':                 '#D4D4D4',
      'editorHoverWidget.statusBarBackground':        '#1e1e1e',
      'editorHoverWidget.highlightForeground':        '#0097FB',

      // ── Parameter hints popup ─────────────────────────────────────────────
      'parameterHints.background':                    '#252526',

      // ── Find / Replace + all other editor widgets ─────────────────────────
      'editorWidget.background':                      '#252526',
      'editorWidget.border':                          '#454545',
      'editorWidget.foreground':                      '#CCCCCC',
      'editorWidget.resizeBorder':                    '#5F5F5F',

      // ── Context menu ──────────────────────────────────────────────────────
      'menu.background':                              '#252526',
      'menu.foreground':                              '#CCCCCC',
      'menu.selectionBackground':                     '#04395E',
      'menu.selectionForeground':                     '#FFFFFF',
      'menu.separatorBackground':                     '#454545',
      'menu.border':                                  '#454545',

      // ── Inline ghost text ─────────────────────────────────────────────────
      'editorGhostText.foreground':                   '#5A5A5A',

      // ── Quick input / command palette ─────────────────────────────────────
      'quickInput.background':                        '#252526',
      'quickInput.foreground':                        '#CCCCCC',
      'quickInputList.focusBackground':               '#04395E',
      'quickInputTitle.background':                   '#1e1e1e',

      // ── Peek / reference view ─────────────────────────────────────────────
      'peekView.border':                              '#007ACC',
      'peekViewEditor.background':                    '#001F33',
      'peekViewEditor.matchHighlightBackground':      '#FF8F0099',
      'peekViewResult.background':                    '#252526',
      'peekViewResult.fileForeground':                '#FFFFFF',
      'peekViewResult.lineForeground':                '#BBBBBB',
      'peekViewResult.matchHighlightBackground':      '#EA5C004D',
      'peekViewResult.selectionBackground':           '#3399FF33',
      'peekViewResult.selectionForeground':           '#FFFFFF',
      'peekViewTitle.background':                     '#1e1e1e',
      'peekViewTitleDescription.foreground':          '#CCCCCCB3',
      'peekViewTitleLabel.foreground':                '#FFFFFF',

      // ── Notifications ─────────────────────────────────────────────────────
      'notificationCenter.border':                    '#454545',
      'notificationCenterHeader.background':          '#252526',
      'notificationCenterHeader.foreground':          '#CCCCCC',
      'notifications.background':                     '#252526',
      'notifications.border':                         '#454545',
      'notifications.foreground':                     '#CCCCCC',
      'notificationToast.border':                     '#454545',
    },
  });
  monaco.editor.setTheme(themeName);
}