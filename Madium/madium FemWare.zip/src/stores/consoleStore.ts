import { listen, type UnlistenFn } from '@tauri-apps/api/event';

export type ConsoleLogLevel = 'info' | 'warning' | 'error' | 'success' | 'status';
export type LogSource = 'femware' | 'roblox';

export interface ConsoleLogEntry {
  id: string;
  level: ConsoleLogLevel;
  message: string;
  timestamp: Date;
  source: LogSource;
}

interface ConsoleLogPayload {
  level?: string;
  message?: string;
}

let logs: ConsoleLogEntry[] = [];
const listeners = new Set<() => void>();
let unlisten: UnlistenFn | null = null;
let started = false;

function notify(): void {
  listeners.forEach((listener) => listener());
}

function normalizeLevel(level?: string): ConsoleLogLevel {
  if (level === 'warning' || level === 'error' || level === 'success' || level === 'status') {
    return level;
  }
  return 'info';
}

function nextId(): string {
  return `console_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

// Register the Tauri event listener once. Safe to call multiple times.
export function initializeConsoleListener(): void {
  if (started) return;
  started = true;

  listen<ConsoleLogPayload>('console-log', (event) => {
    appendConsoleLog({
      level: normalizeLevel(event.payload?.level),
      message: event.payload?.message ?? '',
      source: 'roblox',
    });
  }).then((fn) => {
    unlisten = fn;
  });
}

export function appendConsoleLog(entry: Omit<ConsoleLogEntry, 'id' | 'timestamp'>): void {
  logs = [
    ...logs,
    {
      id: nextId(),
      timestamp: new Date(),
      ...entry,
    },
  ].slice(-500);

  notify();
}

export function clearConsoleLogs(): void {
  if (logs.length === 0) return;
  logs = [];
  notify();
}

// Clear only Roblox redirect logs
export function clearRobloxLogs(): void {
  const robloxLogs = logs.filter(log => log.source === 'roblox');
  if (robloxLogs.length === 0) return;
  logs = logs.filter(log => log.source !== 'roblox');
  notify();
}

export function getConsoleLogs(): ConsoleLogEntry[] {
  return [...logs];
}

// Get only Roblox redirect logs (for OutputTab)
export function getRobloxLogs(): ConsoleLogEntry[] {
  return logs.filter(log => log.source === 'roblox');
}

export function subscribeToConsoleLogs(callback: () => void): () => void {
  listeners.add(callback);
  return () => listeners.delete(callback);
}

// Auto-start as soon as this module is imported, same pattern as attachStore.
initializeConsoleListener();