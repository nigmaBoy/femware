import { invoke } from '@tauri-apps/api/core';

type AttachState = 'detached' | 'attaching' | 'attached';

export interface RobloxProcess {
  pid: number;
  name: string;
  username?: string;
}

interface AttachStore {
  state: AttachState;
  selectedPids: number[];
  processes: RobloxProcess[];
  attachedProcesses: RobloxProcess[];
  hasAttached: boolean;
}

let store: AttachStore = {
  state: 'detached',
  selectedPids: [],
  processes: [],
  attachedProcesses: [],
  hasAttached: false,
};

const listeners = new Set<() => void>();

function notify() {
  listeners.forEach((listener) => listener());
}

export function getAttachState(): AttachState {
  return store.state;
}

export function isDmaMode(): boolean {
  return false;
}

export function getProcesses(): RobloxProcess[] {
  return store.processes;
}

export function getAttachedProcesses(): RobloxProcess[] {
  return store.attachedProcesses;
}

export function getSelectedPids(): number[] {
  return store.selectedPids;
}

export function getHasAttached(): boolean {
  return store.hasAttached;
}

export function setHasAttached(value: boolean): void {
  store = { ...store, hasAttached: value };
  notify();
}

export function setSelectedPids(pids: number[]): void {
  store = { ...store, selectedPids: pids };
  notify();
}

export function togglePid(pid: number): void {
  const current = store.selectedPids;
  const next = current.includes(pid)
    ? current.filter((p) => p !== pid)
    : [...current, pid];
  store = { ...store, selectedPids: next };
  notify();
}

export function selectAllPids(): void {
  store = { ...store, selectedPids: store.processes.map((p) => p.pid) };
  notify();
}

export function deselectAllPids(): void {
  store = { ...store, selectedPids: [] };
  notify();
}

export async function refreshProcesses(): Promise<void> {
  // No-op for Madium
}

export function subscribeAttach(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function startAttaching(): void {
  store = { ...store, state: 'attaching' };
  notify();
}

export async function setAttached(): Promise<void> {
  store = { ...store, state: 'attached', hasAttached: true };
  notify();
}

export async function setDetached(): Promise<void> {
  store = { ...store, state: 'detached', hasAttached: false, attachedProcesses: [], processes: [], selectedPids: [] };
  notify();
}

export async function performAttach(invokeFunc: () => Promise<void>): Promise<void> {
  await invokeFunc();
}

// Static bridge to hook up Madium handshake data 
export function setAttachedState(attached: boolean, pids: number[] = []) {
  let nextPids = [...store.selectedPids];
  
  if (attached) {
    // Append new pids dynamically, avoiding duplicates
    for (const pid of pids) {
      if (!nextPids.includes(pid)) {
        nextPids.push(pid);
      }
    }
  } else {
    if (pids.length === 0) {
      nextPids = [];
    } else {
      // Subtract only the disconnected pids, leaving the others active
      nextPids = nextPids.filter(pid => !pids.includes(pid));
    }
  }

  const nextState = nextPids.length > 0 ? 'attached' : 'detached';
  const robloxProcesses = nextPids.map(pid => ({ pid, name: `Roblox (PID ${pid})` }));

  store = {
    ...store,
    state: nextState,
    hasAttached: nextPids.length > 0,
    processes: robloxProcesses,
    attachedProcesses: robloxProcesses,
    selectedPids: nextPids,
  };
  notify();
}


export async function executeScript(script: string): Promise<void> {
  const pids = getSelectedPids();
  await invoke('execute_madium', { script, pids });
}