use tokio::sync::{mpsc, Mutex};
use tokio::net::TcpListener;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio_tungstenite::accept_async;
use futures_util::{SinkExt, StreamExt};
use std::sync::Arc;
use std::collections::HashMap;
use tauri::{AppHandle, Emitter};

const CHANNEL_CAPACITY: usize = 64;

#[repr(C)]
#[derive(Copy, Clone)]
struct MIB_TCPROW_OWNER_PID {
    dw_state: u32,
    dw_local_addr: u32,
    dw_local_port: u32,
    dw_remote_addr: u32,
    dw_remote_port: u32,
    dw_owning_pid: u32,
}

#[repr(C)]
struct MIB_TCPTABLE_OWNER_PID {
    dw_num_entries: u32,
    table: [MIB_TCPROW_OWNER_PID; 1],
}

// Low-overhead Win32 system check to verify if process ID is still alive
fn is_pid_running(pid: u32) -> bool {
    if pid == 0 {
        return false;
    }
    unsafe {
        use windows_sys::Win32::System::Threading::{OpenProcess, PROCESS_QUERY_LIMITED_INFORMATION, GetExitCodeProcess, GetProcessVersion};
        use windows_sys::Win32::Foundation::{CloseHandle, STILL_ACTIVE};
        
        // Fast Registry check: returns 0 if process is completely dead / unindexed
        if GetProcessVersion(pid) == 0 {
            return false;
        }

        let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
        if handle.is_null() {
            return false;
        }
        
        let mut exit_code: u32 = 0;
        let success = GetExitCodeProcess(handle, &mut exit_code);
        CloseHandle(handle);
        
        if success != 0 {
            exit_code == STILL_ACTIVE as u32
        } else {
            false
        }
    }
}

// Native Win32 TCP owner resolver
fn get_pid_from_port(port: u16) -> Option<u32> {
    unsafe {
        let lib = windows_sys::Win32::System::LibraryLoader::LoadLibraryA(b"iphlpapi.dll\0".as_ptr());
        if lib.is_null() {
            return None;
        }

        type GetExtendedTcpTableFn = unsafe extern "system" fn(
            pTcpTable: *mut std::ffi::c_void,
            pdwSize: *mut u32,
            bOrder: i32,
            ulAf: u32,
            TableClass: u32,
            Reserved: u32,
        ) -> u32;

        let proc_addr = windows_sys::Win32::System::LibraryLoader::GetProcAddress(
            lib,
            b"GetExtendedTcpTable\0".as_ptr(),
        );

        if let Some(addr) = proc_addr {
            let get_extended_tcp_table: GetExtendedTcpTableFn = std::mem::transmute(addr);
            let mut size: u32 = 0;
            
            // Query size (AF_INET = 2, TCP_TABLE_OWNER_PID_ALL = 5)
            let _ = get_extended_tcp_table(std::ptr::null_mut(), &mut size, 0, 2, 5, 0);

            let mut buffer = vec![0u8; size as usize];
            let result = get_extended_tcp_table(buffer.as_mut_ptr() as *mut _, &mut size, 0, 2, 5, 0);
            
            if result == 0 {
                let table = &*(buffer.as_ptr() as *const MIB_TCPTABLE_OWNER_PID);
                let entries = std::slice::from_raw_parts(
                    table.table.as_ptr(),
                    table.dw_num_entries as usize,
                );
                
                for entry in entries {
                    let entry_port = u16::from_be((entry.dw_local_port & 0xFFFF) as u16);
                    if entry_port == port {
                        return Some(entry.dw_owning_pid);
                    }
                }
            }
        }
    }
    None
}

pub struct MadiumBridge {
    temp_clients: Arc<Mutex<HashMap<u64, mpsc::Sender<String>>>>,
    clients: Arc<Mutex<HashMap<u64, mpsc::Sender<String>>>>,
    conn_to_user: Arc<Mutex<HashMap<u64, u64>>>,
    running: Arc<Mutex<bool>>,
}

impl MadiumBridge {
    pub fn new() -> Self {
        Self {
            temp_clients: Arc::new(Mutex::new(HashMap::new())),
            clients: Arc::new(Mutex::new(HashMap::new())),
            conn_to_user: Arc::new(Mutex::new(HashMap::new())),
            running: Arc::new(Mutex::new(false)),
        }
    }

    pub async fn start(&self, app: AppHandle) {
        let mut running = self.running.lock().await;
        if *running {
            return;
        }
        *running = true;

        let running_flag = self.running.clone();
        let app_clone = app.clone();
        
        let temp_clients_map = self.temp_clients.clone();
        let clients_map = self.clients.clone();
        let conn_to_user_map = self.conn_to_user.clone();

        // 1. HTTP Server on 25651
        tokio::spawn(async move {
            let listener = match TcpListener::bind("127.0.0.1:25651").await {
                Ok(l) => l,
                Err(_) => return,
            };

            while let Ok((mut stream, _)) = listener.accept().await {
                let app_inner = app_clone.clone();
                let temp_clients = temp_clients_map.clone();
                let clients = clients_map.clone();
                let conn_to_user = conn_to_user_map.clone();

                tokio::spawn(async move {
                    let mut buffer = [0; 4096];
                    if let Ok(bytes_read) = stream.read(&mut buffer).await {
                        let request = String::from_utf8_lossy(&buffer[..bytes_read]);
                        if let Some(body_start) = request.find("\r\n\r\n") {
                            let body = request[body_start + 4..].trim();
                            if !body.is_empty() {
                                if let Ok(json_data) = serde_json::from_str::<serde_json::Value>(body) {
                                    if let Some(conn_id_str) = json_data.get("connId").and_then(|v| v.as_str()) {
                                        if let Ok(real_pid) = conn_id_str.parse::<u64>() {
                                            if let Some(user_id) = json_data.get("userId").and_then(|v| v.as_u64()) {
                                                
                                                let mut temp = temp_clients.lock().await;
                                                if let Some(sender) = temp.remove(&real_pid) {
                                                    clients.lock().await.insert(real_pid, sender);
                                                    conn_to_user.lock().await.insert(real_pid, user_id);
                                                    
                                                    let _ = app_inner.emit("madium-handshake", json_data);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        let response = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\nContent-Length: 2\r\n\r\nOK";
                        let _ = stream.write_all(response.as_bytes()).await;
                    }
                });
            }
        });

        // 2. WebSocket Server on 25650
        let app_ws = app.clone();
        let temp_clients_ws = self.temp_clients.clone();
        let clients_ws = self.clients.clone();
        let conn_to_user_ws = self.conn_to_user.clone();

        tokio::spawn(async move {
            let listener = match TcpListener::bind("127.0.0.1:25650").await {
                Ok(l) => l,
                Err(e) => {
                    let _ = app_ws.emit(
                        "console-log",
                        serde_json::json!({
                            "level": "error",
                            "message": format!("Failed to bind port 25650: {}", e),
                        }),
                    );
                    *running_flag.lock().await = false;
                    return;
                }
            };

            loop {
                match listener.accept().await {
                    Ok((stream, _)) => {
                        let app_inner = app_ws.clone();
                        let temp_clients = temp_clients_ws.clone();
                        let clients = clients_ws.clone();
                        let conn_to_user = conn_to_user_ws.clone();

                        tokio::spawn(async move {
                            let peer_addr = stream.peer_addr().ok();
                            let client_port = peer_addr.map(|addr| addr.port()).unwrap_or(0);
                            let roblox_pid = get_pid_from_port(client_port).unwrap_or(0) as u64;

                            let ws_stream = match accept_async(stream).await {
                                Ok(ws) => ws,
                                Err(e) => {
                                    let _ = app_inner.emit(
                                        "console-log",
                                        serde_json::json!({
                                            "level": "error",
                                            "message": format!("WebSocket handshake failed: {}", e),
                                        }),
                                    );
                                    return;
                                }
                            };

                            let (mut ws_tx, mut ws_rx) = ws_stream.split();
                            tokio::time::sleep(tokio::time::Duration::from_millis(500)).await;

                            let (script_tx, mut script_rx) = mpsc::channel::<String>(32);
                            temp_clients.lock().await.insert(roblox_pid, script_tx);

                            let handshake_script = format!(r#"
                                local P = game:GetService("Players")
                                local M = game:GetService("MarketplaceService")
                                local H = game:GetService("HttpService")
                                local lp = P.LocalPlayer
                                local ok, thumb = pcall(function() return P:GetUserThumbnailAsync(lp.UserId, Enum.ThumbnailType.HeadShot, Enum.ThumbnailSize.Size100x100) end)
                                local ok2, gn = pcall(function() return M:GetProductInfo(game.PlaceId).Name end)
                                local info = H:JSONEncode({{
                                    connId = "{}",
                                    username = lp.Name,
                                    displayName = lp.DisplayName,
                                    gameName = ok2 and gn or "Unknown Game",
                                    gameId = game.PlaceId,
                                    jobId = game.JobId,
                                    userId = lp.UserId,
                                    avatarUrl = ok and thumb or ""
                                }})

                                local headers = {{["Content-Type"] = "application/json"}}
                                local url = "http://127.0.0.1:25651"

                                if request then
                                    pcall(function() request({{Url = url, Method = "POST", Headers = headers, Body = info}}) end)
                                elseif syn and syn.request then
                                    pcall(function() syn.request({{Url = url, Method = "POST", Headers = headers, Body = info}}) end)
                                elseif http and http.request then
                                    pcall(function() http.request({{Url = url, Method = "POST", Headers = headers, Body = info}}) end)
                                else
                                    pcall(function() game:HttpPost(url, info, "application/json") end)
                                end
                            "#, roblox_pid);

                            if let Err(_) = ws_tx.send(tokio_tungstenite::tungstenite::Message::Text(handshake_script)).await {
                                return;
                            }

                            let _ = app_inner.emit(
                                "console-log",
                                serde_json::json!({
                                    "level": "success",
                                    "message": "Successfully attached to instance",
                                }),
                            );

                            let forward_task = tokio::spawn(async move {
                                while let Some(script) = script_rx.recv().await {
                                    if let Err(_) = ws_tx.send(tokio_tungstenite::tungstenite::Message::Text(script)).await {
                                        break;
                                    }
                                }
                            });

                            while let Some(msg) = ws_rx.next().await {
                                match msg {
                                    Ok(tokio_tungstenite::tungstenite::Message::Close(_)) => break,
                                    Err(_) => break,
                                    _ => {}
                                }
                            }

                            forward_task.abort();
                            temp_clients.lock().await.remove(&roblox_pid);
                            
                            let mut mapping = conn_to_user.lock().await;
                            if let Some(_user_id) = mapping.remove(&roblox_pid) {
                                clients.lock().await.remove(&roblox_pid);
                                let _ = app_inner.emit("madium-disconnect", serde_json::json!({ "userId": roblox_pid }));
                            }
                        });
                    }
                    Err(_) => {}
                }
            }
        });

        // 3. Dual-Queue Process Exit Watch-Dog Loop
        let clients_watch = self.clients.clone();
        let temp_clients_watch = self.temp_clients.clone();
        let conn_to_user_watch = self.conn_to_user.clone();
        let app_watch = app.clone();

        tokio::spawn(async move {
            loop {
                tokio::time::sleep(tokio::time::Duration::from_millis(1000)).await;
                
                // Sweep dead PIDs out of the temp (handshaking) registry
                let mut dead_temps = Vec::new();
                {
                    let temp = temp_clients_watch.lock().await;
                    for &pid in temp.keys() {
                        if !is_pid_running(pid as u32) {
                            dead_temps.push(pid);
                        }
                    }
                }
                for pid in dead_temps {
                    temp_clients_watch.lock().await.remove(&pid);
                }

                // Sweep dead PIDs out of the active registry and broadcast disconnects
                let mut dead_actives = Vec::new();
                {
                    let actives = clients_watch.lock().await;
                    for &pid in actives.keys() {
                        if !is_pid_running(pid as u32) {
                            dead_actives.push(pid);
                        }
                    }
                }

                for pid in dead_actives {
                    let mut active_clients = clients_watch.lock().await;
                    active_clients.remove(&pid);
                    
                    let mut mapping = conn_to_user_watch.lock().await;
                    mapping.remove(&pid);
                    
                    let _ = app_watch.emit(
                        "console-log",
                        serde_json::json!({
                            "level": "warning",
                            "message": format!("Process {} disconnected or terminated.", pid),
                        }),
                    );
                    
                    let _ = app_watch.emit("madium-disconnect", serde_json::json!({ "userId": pid }));
                }
            }
        });
    }

    pub fn send_script(&self, script: String) -> Result<(), String> {
        let clients = self.clients.clone();
        tokio::spawn(async move {
            let map = clients.lock().await;
            for sender in map.values() {
                let _ = sender.send(script.clone()).await;
            }
        });
        Ok(())
    }

    pub async fn send_script_selective(&self, script: String, pids: Option<Vec<u64>>) -> Result<(), String> {
        let clients = self.clients.lock().await;
        
        if clients.is_empty() {
            return Err("No active connections found".to_string());
        }

        match pids {
            Some(ref targets) if !targets.is_empty() => {
                for id in targets {
                    if let Some(sender) = clients.get(id) {
                        let _ = sender.send(script.clone()).await;
                    }
                }
            }
            _ => {
                for sender in clients.values() {
                    let _ = sender.send(script.clone()).await;
                }
            }
        }
        Ok(())
    }

    pub async fn get_connected_count(&self) -> usize {
        self.clients.lock().await.len()
    }

    pub async fn is_connected(&self) -> bool {
        !self.clients.lock().await.is_empty()
    }
}